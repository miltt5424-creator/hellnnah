import React, { useState, useEffect } from 'react';
import { useSignalStore } from '../../store/signalStore';

interface AutoStatus {
  running: boolean;
  intervalMinutes: number;
  clients: number;
}

export default function AutoSignalPanel() {
  const [status, setStatus]       = useState<AutoStatus | null>(null);
  const [interval, setIntervalMin] = useState(5);
  const [loading, setLoading]     = useState(false);
  const signals = useSignalStore((s) => s.signals);
  const autoSignals = signals.filter((s) => (s as any).source === 'scheduler');

  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/autosignal/status', { credentials: 'include' });
      const d   = await res.json();
      if (d.success) setStatus(d);
    } catch { /**/ }
  };

  useEffect(() => { fetchStatus(); const t = setInterval(fetchStatus, 10000); return () => clearInterval(t); }, []);

  const toggle = async () => {
    setLoading(true);
    try {
      const running = status?.running;
      const url     = running ? '/api/autosignal/stop' : '/api/autosignal/start';
      const body    = running ? {} : { interval };
      const res     = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body),
      });
      const d = await res.json();
      if (d.success) setStatus(d);
    } catch { /**/ } finally { setLoading(false); }
  };

  return (
    <div className="panel">
      <div className="panel-header">
        <span className="panel-title">🤖 AUTO-SIGNAL</span>
        {status?.running && (
          <span style={{ fontSize: 9, color: 'var(--buy)', fontFamily: 'Space Mono, monospace' }} className="anim-pulse">
            ● ACTIF
          </span>
        )}
      </div>
      <div className="panel-body">
        {/* Contrôle */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 4 }}>INTERVALLE</div>
            <div style={{ display: 'flex', gap: 4 }}>
              {[1, 3, 5, 10, 15, 30].map((m) => (
                <button
                  key={m}
                  onClick={() => setIntervalMin(m)}
                  disabled={status?.running}
                  className="btn btn-ghost"
                  style={{
                    fontSize: 9, padding: '3px 6px', flex: 1,
                    borderColor: interval === m ? 'var(--gold)' : 'var(--border)',
                    color: interval === m ? 'var(--gold)' : 'var(--text-muted)',
                    background: interval === m ? 'var(--gold-soft)' : 'transparent',
                  }}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>

          <button
            className={status?.running ? 'btn btn-sell' : 'btn btn-buy'}
            style={{ padding: '8px 14px', marginTop: 14, fontSize: 11 }}
            onClick={toggle}
            disabled={loading}
          >
            {loading ? <span className="spinner" /> : status?.running ? '⏹ STOP' : '▶ START'}
          </button>
        </div>

        {/* Status */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6,
          marginBottom: status?.running ? 10 : 0,
        }}>
          {[
            { label: 'ÉTAT',    value: status?.running ? 'ON' : 'OFF', color: status?.running ? 'var(--buy)' : 'var(--text-muted)' },
            { label: 'INTERVALLE', value: status ? `${status.intervalMinutes}m` : '--', color: 'var(--gold)' },
            { label: 'GÉNÉRÉS',   value: String(autoSignals.length), color: 'var(--text-primary)' },
          ].map(({ label, value, color }) => (
            <div key={label} style={{ background: 'var(--glass-card)', borderRadius: 'var(--r-sm)', padding: '6px 8px', textAlign: 'center', border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 8, color: 'var(--text-muted)', marginBottom: 2 }}>{label}</div>
              <div style={{ fontSize: 12, fontWeight: 700, fontFamily: 'Space Mono, monospace', color }}>{value}</div>
            </div>
          ))}
        </div>

        {/* Derniers auto-signaux enrichis */}
        {autoSignals.length > 0 && (
          <div>
            <div style={{ fontSize: 9, color: 'var(--text-muted)', marginBottom: 5, letterSpacing:'0.1em' }}>DERNIERS AUTO-SIGNAUX</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5, maxHeight: 340, overflowY: 'auto' }}>
              {autoSignals.slice(0, 5).map((s: any, i) => {
                const sigColor = s.signal === 'BUY' ? 'var(--buy)' : s.signal === 'SELL' ? 'var(--sell)' : 'var(--text-muted)';
                return (
                  <div key={i} style={{
                    padding: '8px 10px', background: s.signal === 'BUY' ? 'rgba(0,230,118,0.05)' : s.signal === 'SELL' ? 'rgba(255,51,85,0.05)' : 'var(--glass-card)',
                    border: `1px solid ${s.signal === 'BUY' ? 'rgba(0,230,118,0.2)' : s.signal === 'SELL' ? 'rgba(255,51,85,0.2)' : 'var(--border)'}`,
                    borderRadius: 10,
                  }}>
                    {/* Header */}
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:5 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                        <span style={{ fontSize:11, fontWeight:900, color:sigColor }}>{s.signal}</span>
                        <span style={{ fontSize:10, color:'var(--text-primary)', fontFamily:'Space Mono,monospace', fontWeight:700 }}>{s.symbol}</span>
                        {s.mtfConfluence && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background: s.mtfConfluence==='HIGH'?'rgba(0,230,118,0.15)':'rgba(255,193,7,0.15)', color: s.mtfConfluence==='HIGH'?'var(--buy)':'var(--gold)', fontWeight:700 }}>{s.mtfConfluence}</span>}
                      </div>
                      <span style={{ fontSize:8, color:'var(--text-muted)' }}>
                        {new Date(s.timestamp).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}
                      </span>
                    </div>
                    {/* Niveaux */}
                    <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:4, marginBottom:5 }}>
                      {[['ENTRÉE', s.entry, 'var(--text-primary)'], ['SL', s.stopLoss, 'var(--sell)'], ['TP', s.takeProfit, 'var(--buy)']].map(([label, val, color]) => (
                        <div key={label as string} style={{ textAlign:'center', padding:'3px', background:'rgba(255,255,255,0.04)', borderRadius:5 }}>
                          <div style={{ fontSize:7, color:'var(--text-muted)' }}>{label}</div>
                          <div style={{ fontSize:8, fontFamily:'Space Mono,monospace', fontWeight:700, color: color as string }}>{val}</div>
                        </div>
                      ))}
                    </div>
                    {/* Badges indicateurs */}
                    <div style={{ display:'flex', flexWrap:'wrap', gap:3 }}>
                      {s.rr && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(255,255,255,0.06)', color:'var(--gold)', fontFamily:'Space Mono,monospace' }}>RR {s.rr}x</span>}
                      {s.confidence && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(255,255,255,0.06)', color:'var(--text-dim)' }}>CONF {s.confidence}%</span>}
                      {s.adx?.isStrong && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(233,30,99,0.15)', color:'#E91E63' }}>ADX {s.adx.adx}💪</span>}
                      {s.fibonacci?.inOTE && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(255,152,0,0.15)', color:'#FF9800' }}>OTE 🌀</span>}
                      {s.ichimoku && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background: s.ichimoku.aboveCloud?'rgba(0,230,118,0.1)':'rgba(255,51,85,0.1)', color: s.ichimoku.aboveCloud?'var(--buy)':'var(--sell)' }}>☁️ {s.ichimoku.aboveCloud?'↑':'↓'}</span>}
                      {s.supertrend && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background: s.supertrend.direction==='bullish'?'rgba(0,230,118,0.1)':'rgba(255,51,85,0.1)', color: s.supertrend.direction==='bullish'?'var(--buy)':'var(--sell)' }}>ST {s.supertrend.direction==='bullish'?'↑':'↓'}{s.supertrend.crossed?' 🔔':''}</span>}
                      {s.divergence && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background: s.divergence.type?.includes('bullish')?'rgba(0,230,118,0.1)':'rgba(255,51,85,0.1)', color: s.divergence.type?.includes('bullish')?'var(--buy)':'var(--sell)' }}>DIV📊</span>}
                      {s.regime?.regime && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(0,188,212,0.1)', color:'#00BCD4' }}>{s.regime.regime==='compression'?'⚡':s.regime.regime==='expansion'?'🚀':'🎯'} {s.regime.regime}</span>}
                      {s.mss && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(156,39,176,0.15)', color:'#9C27B0' }}>MSS {s.mss.type==='bullish'?'↑':'↓'}</span>}
                      {s.premiumDiscount && s.premiumDiscount.zone !== 'equilibrium' && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background: s.premiumDiscount.zone==='discount'?'rgba(0,230,118,0.1)':'rgba(255,51,85,0.1)', color: s.premiumDiscount.zone==='discount'?'var(--buy)':'var(--sell)' }}>💎 {s.premiumDiscount.zone}</span>}
                      {s.kellySafe && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(255,193,7,0.1)', color:'var(--gold)' }}>Kelly {s.kellySafe}%</span>}
                      {s.dxyBias && ['XAU/USD','EUR/USD','GBP/USD'].includes(s.symbol) && <span style={{ fontSize:7, padding:'1px 5px', borderRadius:4, background:'rgba(255,255,255,0.06)', color: s.dxyBias==='bearish'?'var(--buy)':'var(--sell)' }}>DXY {s.dxyBias==='bearish'?'↓':'↑'}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {!status?.running && (
          <div style={{ fontSize: 10, color: 'var(--text-muted)', textAlign: 'center', padding: '8px 0' }}>
            Configure l'intervalle puis clique START.<br />
            Les signaux arrivent en temps réel via WebSocket.
          </div>
        )}
      </div>
    </div>
  );
}