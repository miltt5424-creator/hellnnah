import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useSignalStore } from '../../store/signalStore';
import { useMarketStore }  from '../../store/marketStore';
import { formatPrice }     from '../../utils/priceFormat';

type BotMode = 'auto' | 'semi' | 'off';

interface ConfirmModal {
  side: 'BUY' | 'SELL';
  symbol: string;
  stopLoss: number;
  takeProfit: number;
  confidence: number;
  entry: number;
  rr: string;
  compositeScore: number;
}

// ── Filtre de qualité signal ─────────────────────────────────────
interface BotFilter {
  minConfidence: number;
  minScore: number;
  minRR: number;
  maxSimultaneous: number;
  allowedSymbols: string[];
  requireMTFHigh: boolean;
  requireOTE: boolean;
  requireKillZone: boolean;
}

const DEFAULT_FILTER: BotFilter = {
  minConfidence: 60,
  minScore: 25,
  minRR: 1.5,
  maxSimultaneous: 3,
  allowedSymbols: ['BTC/USD', 'ETH/USD', 'XAU/USD', 'EUR/USD', 'GBP/USD'],
  requireMTFHigh: false,
  requireOTE: false,
  requireKillZone: false,
};

function passesFilter(sig: any, filter: BotFilter): { ok: boolean; reason?: string } {
  if (!sig || sig.signal === 'HOLD') return { ok: false, reason: 'Signal HOLD' };
  if ((sig.confidence || 0) < filter.minConfidence) return { ok: false, reason: `Conf ${sig.confidence}% < ${filter.minConfidence}% min` };
  if (Math.abs(sig.compositeScore || 0) < filter.minScore) return { ok: false, reason: `Score ${sig.compositeScore} < ${filter.minScore} min` };
  const rr = sig.stopLoss && sig.takeProfit && sig.entry
    ? Math.abs((sig.takeProfit - sig.entry) / (sig.entry - sig.stopLoss)) : 0;
  if (rr < filter.minRR) return { ok: false, reason: `RR ${rr.toFixed(1)} < ${filter.minRR} min` };
  if (!filter.allowedSymbols.includes(sig.symbol)) return { ok: false, reason: `${sig.symbol} non autorisé` };
  if (filter.requireMTFHigh && sig.mtfConfluence !== 'HIGH') return { ok: false, reason: 'MTF confluence < HIGH' };
  if (filter.requireOTE && !sig.ote) return { ok: false, reason: 'Pas de zone OTE' };
  if (filter.requireKillZone && !sig.killZone) return { ok: false, reason: 'Pas de Kill Zone active' };
  return { ok: true };
}

function checkMaxTrades(openPos: number, filter: BotFilter): { ok: boolean; reason?: string } {
  if (openPos >= filter.maxSimultaneous) return { ok: false, reason: `Max ${filter.maxSimultaneous} trades simultanés atteint` };
  return { ok: true };
}

const SYMBOLS = ['BTC/USD', 'ETH/USD', 'XAU/USD', 'EUR/USD', 'GBP/USD'];

export default function MT5ExecutionPanel() {
  const [status,    setStatus]    = useState<any>(null);
  const [history,   setHistory]   = useState<any[]>([]);
  const [loading,   setLoading]   = useState(false);
  const [feedback,  setFeedback]  = useState('');
  const [lots,      setLots]      = useState('0.1');
  const [botMode,   setBotMode]   = useState<BotMode>('off');
  const [autoCount, setAutoCount] = useState(0);
  const [confirm,   setConfirm]   = useState<ConfirmModal | null>(null);
  const [filter,    setFilter]    = useState<BotFilter>(DEFAULT_FILTER);
  const [showFilter,setShowFilter]= useState(false);
  const [filterTab, setFilterTab] = useState<'filter'|'history'>('history');
  const [botLog,    setBotLog]    = useState<{ ts: number; msg: string; ok: boolean }[]>([]);
  const [skippedCount, setSkippedCount] = useState(0);
  const [paperMode, setPaperMode]       = useState(false);
  const [paperTrades, setPaperTrades]   = useState<any[]>([]);
  const [paperPnl, setPaperPnl]         = useState(0);

  const lastSigRef = useRef('');
  const latest  = useSignalStore((s) => s.signals[0]);
  const symbol   = useMarketStore((s) => s.symbol);

  const addLog = (msg: string, ok: boolean) => {
    setBotLog(prev => [{ ts: Date.now(), msg, ok }, ...prev].slice(0, 30));
  };

  const fetchStatus = useCallback(async () => {
    try {
      const r = await fetch('/api/mt5/status', { credentials: 'include' });
      setStatus(await r.json());
    } catch {}
  }, []);

  const fetchHistory = useCallback(async () => {
    try {
      const r = await fetch('/api/mt5/history?limit=20', { credentials: 'include' });
      const d = await r.json();
      if (d.success) setHistory(d.trades);
    } catch {}
  }, []);

  useEffect(() => {
    fetchStatus(); fetchHistory();
    const t = setInterval(() => { fetchStatus(); fetchHistory(); }, 5000);
    return () => clearInterval(t);
  }, []);

  // AUTO mode — filtre + place
  useEffect(() => {
    if (botMode !== 'auto') return;
    if (!latest) return;
    const sigId = `${latest.symbol}-${latest.signal}-${latest.timestamp}`;
    if (sigId === lastSigRef.current) return;
    lastSigRef.current = sigId;

    const check = passesFilter(latest, filter);
    if (!check.ok) {
      setSkippedCount(c => c + 1);
      addLog(`⏭ SKIP ${latest.symbol} ${latest.signal} — ${check.reason}`, false);
      return;
    }
    const maxCheck = checkMaxTrades(openPos, filter);
    if (!maxCheck.ok) {
      setSkippedCount(c => c + 1);
      addLog(`⏭ SKIP ${latest.symbol} — ${maxCheck.reason}`, false);
      return;
    }
    addLog(`🚀 AUTO ${latest.signal} ${latest.symbol} — conf ${latest.confidence}%`, true);
    placeOrder(latest.signal as 'BUY' | 'SELL', true);
  }, [latest, botMode, filter]);

  // SEMI mode
  useEffect(() => {
    if (botMode !== 'semi') return;
    if (!latest || !latest.signal || latest.signal === 'HOLD') return;
    const sigId = `${latest.symbol}-${latest.signal}-${latest.timestamp}`;
    if (sigId === lastSigRef.current) return;
    lastSigRef.current = sigId;

    const check = passesFilter(latest, filter);
    if (!check.ok) {
      addLog(`⏭ SKIP ${latest.symbol} — ${check.reason}`, false);
      return;
    }
    const rr = latest.stopLoss && latest.takeProfit && latest.entry
      ? Math.abs((latest.takeProfit - latest.entry) / (latest.entry - latest.stopLoss)).toFixed(1) : '?';
    setConfirm({
      side: latest.signal as 'BUY' | 'SELL',
      symbol: latest.symbol || symbol,
      stopLoss:       latest.stopLoss    || 0,
      takeProfit:     latest.takeProfit  || 0,
      confidence:     latest.confidence  || 0,
      entry:          latest.entry       || 0,
      rr,
      compositeScore: (latest as any).compositeScore || 0,
    });
  }, [latest, botMode, filter]);

  const closePaperTrade = (tradeIdx: number, exitPrice: number) => {
    setPaperTrades(prev => {
      const updated = [...prev];
      const t = updated[tradeIdx];
      if (!t || t.closed) return prev;
      const pnl = t.side === 'BUY' ? (exitPrice - t.entry) * 100 * parseFloat(lots) : (t.entry - exitPrice) * 100 * parseFloat(lots);
      updated[tradeIdx] = { ...t, closed: true, exit: exitPrice, pnl: parseFloat(pnl.toFixed(2)), closedAt: new Date().toLocaleTimeString() };
      setPaperPnl(p => parseFloat((p + updated[tradeIdx].pnl).toFixed(2)));
      return updated;
    });
  };

  const placeOrder = async (side: 'BUY' | 'SELL', isAuto = false, overrideSymbol?: string) => {
    // PAPER TRADING — simuler sans envoyer à MT5
    if (paperMode) {
      const orderSym = overrideSymbol || latest?.symbol || symbol;
      const entry    = latest?.entry || 0;
      const sl       = latest?.stopLoss || 0;
      const tp       = latest?.takeProfit || 0;
      const trade    = { id: Date.now(), side, symbol: orderSym, entry, sl, tp, lots: parseFloat(lots), openedAt: new Date().toLocaleTimeString(), closed: false };
      setPaperTrades(prev => [trade, ...prev].slice(0, 20));
      const msg = `📄 PAPER ${side} ${orderSym} @${entry} | SL:${sl} TP:${tp}`;
      setFeedback(msg); addLog(msg, true);
      if (isAuto) setAutoCount(c => c + 1);
      setConfirm(null); setLoading(false);
      return;
    }
    setLoading(true); setFeedback(''); setConfirm(null);
    const orderSym   = overrideSymbol || latest?.symbol || symbol;
    const stopLoss   = latest?.stopLoss   || 0;
    const takeProfit = latest?.takeProfit || 0;
    const confidence = latest?.confidence || 0;
    try {
      const r = await fetch('/api/mt5/command', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          side, symbol: orderSym,
          stopLoss, takeProfit,
          lots: parseFloat(lots),
          confidence,
          comment: `ElJoven_${isAuto ? 'AUTO' : 'SEMI'}_${confidence}pct`,
        }),
      });
      const d = await r.json();
      if (d.success) {
        const msg = `✅ ${isAuto ? 'AUTO' : 'SEMI'} ${side} ${orderSym} ${lots}lot | SL:${stopLoss > 0 ? formatPrice(stopLoss, 2) : 'N/A'} TP:${takeProfit > 0 ? formatPrice(takeProfit, 2) : 'N/A'}`;
        setFeedback(msg);
        addLog(msg, true);
        if (isAuto) setAutoCount(c => c + 1);
      } else {
        const msg = `❌ ${d.error || 'Erreur inconnue'}`;
        setFeedback(msg);
        addLog(msg, false);
      }
      fetchHistory(); fetchStatus();
    } catch {
      setFeedback('❌ Backend introuvable');
      addLog('❌ Backend introuvable', false);
    }
    finally { setLoading(false); }
  };

  const closeAll = async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/mt5/close-all', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol }),
      });
      const d = await r.json();
      const msg = d.success ? '✅ CLOSE ALL envoyé à MT5' : `❌ ${d.error}`;
      setFeedback(msg);
      addLog(msg, d.success);
      fetchStatus();
    } catch {
      setFeedback('❌ Backend introuvable');
    }
    finally { setLoading(false); }
  };

  const connected  = status?.connected ?? false;
  const sig        = latest?.signal;
  const sigColor   = sig === 'BUY' ? 'var(--buy)' : sig === 'SELL' ? 'var(--sell)' : 'var(--text-dim)';
  const rr         = latest?.stopLoss && latest?.takeProfit && latest?.entry
    ? Math.abs((latest.takeProfit - latest.entry) / (latest.entry - latest.stopLoss)).toFixed(1) : '?';
  const modeColor  = botMode === 'auto' ? 'var(--buy)' : botMode === 'semi' ? 'var(--gold)' : 'var(--text-muted)';
  const openPos    = status?.openPositions ?? 0;
  const curFilter  = passesFilter(latest, filter);

  return (
    <>
      {/* ── Modal confirmation SEMI ── */}
      {confirm && (
        <div style={{ position:'fixed', inset:0, zIndex:9999, background:'rgba(0,0,0,0.8)', backdropFilter:'blur(6px)', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <div style={{ background:'var(--bg-card)', border:`2px solid ${confirm.side==='BUY'?'var(--border-buy)':'var(--border-sell)'}`, borderRadius:16, padding:24, width:320, boxShadow:'0 20px 60px rgba(0,0,0,0.6)' }}>
            <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:8 }}>⚡ SEMI-AUTO — CONFIRMATION REQUISE</div>
            <div style={{ fontSize:32, fontWeight:900, color:confirm.side==='BUY'?'var(--buy)':'var(--sell)', marginBottom:4 }}>
              {confirm.side==='BUY'?'▲':'▼'} {confirm.side}
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:14 }}>
              <span style={{ fontSize:13, color:'var(--text-primary)' }}>{confirm.symbol}</span>
              <div style={{ display:'flex', gap:6 }}>
                <span style={{ fontSize:9, padding:'2px 8px', borderRadius:20, background:'rgba(255,255,255,0.07)', color:'var(--text-muted)' }}>CONF {confirm.confidence}%</span>
                <span style={{ fontSize:9, padding:'2px 8px', borderRadius:20, background:'rgba(255,193,7,0.1)', color:'var(--gold)' }}>RR {confirm.rr}x</span>
              </div>
            </div>

            {/* Score visuel */}
            <div style={{ marginBottom:12, padding:'6px 10px', borderRadius:8, background:'rgba(255,255,255,0.03)', border:'1px solid var(--border)' }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontSize:8, color:'var(--text-muted)' }}>SCORE COMPOSITE</span>
                <span style={{ fontSize:9, fontWeight:700, color:confirm.compositeScore>0?'var(--buy)':'var(--sell)', fontFamily:'Space Mono,monospace' }}>{confirm.compositeScore>0?'+':''}{confirm.compositeScore}</span>
              </div>
              <div style={{ height:4, background:'rgba(255,255,255,0.06)', borderRadius:2, overflow:'hidden' }}>
                <div style={{ height:'100%', width:`${Math.abs(confirm.compositeScore)/2}%`, marginLeft:confirm.compositeScore>=0?'50%':`${50-Math.abs(confirm.compositeScore)/2}%`, background:confirm.compositeScore>0?'var(--buy)':'var(--sell)', borderRadius:2 }} />
              </div>
            </div>

            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:12 }}>
              <div style={{ padding:'8px', background:'var(--sell-dim)', borderRadius:8, border:'1px solid var(--border-sell)', textAlign:'center' }}>
                <div style={{ fontSize:8, color:'var(--sell)', marginBottom:2 }}>🛑 STOP LOSS</div>
                <div style={{ fontSize:13, fontWeight:700, color:'var(--sell)', fontFamily:'Space Mono,monospace' }}>{confirm.stopLoss>0?formatPrice(confirm.stopLoss,2):'—'}</div>
              </div>
              <div style={{ padding:'8px', background:'var(--buy-dim)', borderRadius:8, border:'1px solid var(--border-buy)', textAlign:'center' }}>
                <div style={{ fontSize:8, color:'var(--buy)', marginBottom:2 }}>🎯 TAKE PROFIT</div>
                <div style={{ fontSize:13, fontWeight:700, color:'var(--buy)', fontFamily:'Space Mono,monospace' }}>{confirm.takeProfit>0?formatPrice(confirm.takeProfit,2):'—'}</div>
              </div>
            </div>
            <div style={{ fontSize:10, color:'var(--text-muted)', marginBottom:16, textAlign:'center' }}>{lots} lot · entrée ~{formatPrice(confirm.entry,2)}</div>

            <div style={{ display:'flex', gap:8 }}>
              <button onClick={() => { setConfirm(null); addLog(`⏭ SKIP manuel ${confirm.symbol}`, false); }} style={{ flex:1, padding:'10px', borderRadius:8, cursor:'pointer', background:'transparent', border:'1px solid var(--border)', color:'var(--text-muted)', fontSize:12, fontWeight:700 }}>✕ SKIP</button>
              <button onClick={() => placeOrder(confirm.side, false, confirm.symbol)} disabled={loading} style={{ flex:2, padding:'10px', borderRadius:8, cursor:'pointer', background:confirm.side==='BUY'?'var(--buy-dim)':'var(--sell-dim)', border:`1px solid ${confirm.side==='BUY'?'var(--border-buy)':'var(--border-sell)'}`, color:confirm.side==='BUY'?'var(--buy)':'var(--sell)', fontSize:13, fontWeight:900 }}>
                {loading?'...':`✅ CONFIRMER ${confirm.side}`}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="panel" style={{ borderColor:botMode==='auto'?'rgba(0,255,136,0.4)':botMode==='semi'?'rgba(255,215,0,0.3)':'var(--border)', display:'flex', flexDirection:'column', gap:0 }}>

        {/* ── Header ── */}
        <div className="panel-header">
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ fontSize:18 }}>🤖</span>
            <div>
              <div className="panel-title">AUTO TRADE BOT</div>
              <div style={{ fontSize:8, color:'var(--text-muted)', marginTop:1 }}>
                {connected ? `MT5 · ${status.accountId} · $${status.balance?.toFixed(0)} · ${openPos} pos ouvertes` : 'MT5 NON CONNECTÉ'}
              </div>
            </div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:6, padding:'3px 10px', borderRadius:20, background:botMode!=='off'?'var(--buy-dim)':'rgba(255,255,255,0.05)', border:`1px solid ${modeColor}` }}>
            <span style={{ width:6, height:6, borderRadius:'50%', background:modeColor, animation:botMode!=='off'?'pulseDot 1.5s infinite':'none' }} />
            <span style={{ fontSize:9, fontWeight:700, color:modeColor, fontFamily:'Space Mono,monospace' }}>
              {botMode==='auto'?'🤖 AUTO':botMode==='semi'?'⚡ SEMI':'⏸ PAUSE'}
            </span>
          </div>
        </div>

        {/* ── Stats bar ── */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:4, padding:'8px 14px', borderBottom:'1px solid var(--border)' }}>
          {[
            { label:'BALANCE',  val:connected?`$${status.balance?.toFixed(0)}`:'—',          color:'var(--gold)' },
            { label:'ÉQUITÉ',   val:connected?`$${status.equity?.toFixed(0)}`:'—',            color:connected&&status.equity>=status.balance?'var(--buy)':'var(--sell)' },
            { label:'POSITION', val:`${openPos}`,                                             color:openPos>0?'var(--gold)':'var(--text-muted)' },
            { label:'AUTO SKIP',val:`${autoCount}✅ ${skippedCount}⏭`,                        color:'var(--text-dim)' },
          ].map(({ label, val, color }) => (
            <div key={label} className="card" style={{ textAlign:'center', padding:'5px 4px' }}>
              <div style={{ fontSize:7, color:'var(--text-muted)', marginBottom:2 }}>{label}</div>
              <div style={{ fontFamily:'Space Mono,monospace', fontSize:8, fontWeight:700, color }}>{val}</div>
            </div>
          ))}
        </div>

        <div className="panel-body" style={{ display:'flex', flexDirection:'column', gap:10 }}>

          {/* ── Signal actif + statut filtre ── */}
          {latest && (
            <div className="card" style={{ padding:'8px 10px', borderColor:`${sigColor}40` }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
                <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                  <span style={{ fontSize:22, fontWeight:900, color:sigColor }}>{sig}</span>
                  <div>
                    <div style={{ fontSize:9, color:'var(--text-muted)' }}>{latest.symbol} · {latest.confidence}% conf</div>
                    <div style={{ fontSize:8, fontFamily:'Space Mono,monospace', color:'var(--text-dim)' }}>Entrée: {formatPrice(latest.entry,2)}</div>
                  </div>
                </div>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-end', gap:3 }}>
                  <div className="badge badge-gold" style={{ fontSize:8 }}>RR {rr}x</div>
                  <div style={{ fontSize:7, padding:'1px 6px', borderRadius:10, background:curFilter.ok?'rgba(0,230,118,0.15)':'rgba(255,51,85,0.15)', color:curFilter.ok?'var(--buy)':'var(--sell)', border:`1px solid ${curFilter.ok?'var(--border-buy)':'var(--border-sell)'}` }}>
                    {curFilter.ok?'✅ PASSE FILTRE':`🚫 ${curFilter.reason}`}
                  </div>
                </div>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:4 }}>
                <div style={{ padding:'4px 8px', background:'var(--sell-dim)', borderRadius:6, border:'1px solid var(--border-sell)', textAlign:'center' }}>
                  <div style={{ fontSize:7, color:'var(--sell)', marginBottom:1 }}>🛑 SL</div>
                  <div style={{ fontSize:11, fontWeight:700, color:'var(--sell)', fontFamily:'Space Mono,monospace' }}>{latest.stopLoss>0?formatPrice(latest.stopLoss,2):'—'}</div>
                </div>
                <div style={{ padding:'4px 8px', background:'var(--buy-dim)', borderRadius:6, border:'1px solid var(--border-buy)', textAlign:'center' }}>
                  <div style={{ fontSize:7, color:'var(--buy)', marginBottom:1 }}>🎯 TP</div>
                  <div style={{ fontSize:11, fontWeight:700, color:'var(--buy)', fontFamily:'Space Mono,monospace' }}>{latest.takeProfit>0?formatPrice(latest.takeProfit,2):'—'}</div>
                </div>
              </div>
            </div>
          )}

          {/* ── Mode sélecteur ── */}
          <div>
            <div style={{ fontSize:9, color:'var(--text-muted)', marginBottom:5 }}>MODE DU BOT</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:5 }}>
              {([
                { mode:'auto' as BotMode, label:'🤖 AUTO',  desc:'Place sans confirmation' },
                { mode:'semi' as BotMode, label:'⚡ SEMI',  desc:'Confirme avant de placer' },
                { mode:'off'  as BotMode, label:'⏸ PAUSE', desc:'Manuel uniquement' },
              ]).map(({ mode, label, desc }) => (
                <button key={mode} onClick={() => setBotMode(mode)} title={desc} style={{
                  padding:'8px 4px', borderRadius:8, cursor:'pointer', border:'1px solid',
                  borderColor: botMode===mode?(mode==='auto'?'var(--buy)':mode==='semi'?'var(--gold)':'var(--text-muted)'):'var(--border)',
                  background:  botMode===mode?(mode==='auto'?'var(--buy-dim)':mode==='semi'?'var(--gold-soft)':'rgba(255,255,255,0.03)'):'transparent',
                  color:       botMode===mode?(mode==='auto'?'var(--buy)':mode==='semi'?'var(--gold)':'var(--text-muted)'):'var(--text-muted)',
                  fontSize:9, fontWeight:700, textAlign:'center' as const,
                }}>{label}</button>
              ))}
            </div>
          </div>

          {/* ── Lot size + filtres ── */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr auto', gap:8, alignItems:'end' }}>
            <div>
              <div style={{ fontSize:9, color:'var(--text-muted)', marginBottom:3 }}>TAILLE LOT</div>
              <div style={{ display:'flex', gap:4, alignItems:'center' }}>
                <input className="input" type="number" min="0.01" step="0.01"
                  value={lots} onChange={e => setLots(e.target.value)} style={{ width:60 }} />
                <div style={{ display:'flex', gap:3 }}>
                  {['0.1','0.2','0.5','1.0'].map(v => (
                    <button key={v} className="btn btn-sm btn-ghost" style={{ fontSize:8, padding:'2px 5px' }} onClick={() => setLots(v)}>{v}</button>
                  ))}
                </div>
              </div>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
              <button onClick={() => setPaperMode(p=>!p)} style={{ padding:'6px 10px', borderRadius:8, border:`1px solid ${paperMode?'rgba(147,112,219,0.6)':'var(--border)'}`, background:paperMode?'rgba(147,112,219,0.12)':'transparent', color:paperMode?'#b39ddb':'var(--text-muted)', fontSize:9, fontWeight:700, cursor:'pointer', whiteSpace:'nowrap' }}>
                📄 {paperMode ? 'PAPER ON' : 'PAPER'}
              </button>
              <button onClick={() => setShowFilter(f=>!f)} style={{ padding:'6px 10px', borderRadius:8, border:`1px solid ${showFilter?'var(--gold)':'var(--border)'}`, background:showFilter?'var(--gold-soft)':'transparent', color:showFilter?'var(--gold)':'var(--text-muted)', fontSize:9, fontWeight:700, cursor:'pointer' }}>
              ⚙️ FILTRES
            </button>
            </div>
          </div>

          {/* ── Panel filtres ── */}
          {showFilter && (
            <div style={{ padding:'10px', borderRadius:10, background:'rgba(255,255,255,0.03)', border:'1px solid var(--border)' }}>
              <div style={{ fontSize:9, color:'var(--text-muted)', marginBottom:8, letterSpacing:'0.1em' }}>⚙️ FILTRES DE QUALITÉ SIGNAL</div>

              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6, marginBottom:8, gridTemplateColumns:'repeat(2,1fr)' }}>
                {[
                  { label:'CONF MIN %',   val:filter.minConfidence,  key:'minConfidence',  min:0, max:100, step:5 },
                  { label:'SCORE MIN',    val:filter.minScore,       key:'minScore',       min:0, max:100, step:5 },
                  { label:'RR MIN',       val:filter.minRR,          key:'minRR',          min:1, max:5,   step:0.5 },
                  { label:'MAX TRADES',   val:filter.maxSimultaneous,key:'maxSimultaneous',min:1, max:10,  step:1 },
                ].map(({ label, val, key, min, max, step }) => (
                  <div key={key}>
                    <div style={{ fontSize:8, color:'var(--text-muted)', marginBottom:3 }}>{label}</div>
                    <div style={{ display:'flex', alignItems:'center', gap:4 }}>
                      <input type="range" min={min} max={max} step={step} value={val}
                        onChange={e => setFilter(f => ({ ...f, [key]: parseFloat(e.target.value) }))}
                        style={{ flex:1 }} />
                      <span style={{ fontSize:9, fontFamily:'Space Mono,monospace', color:'var(--gold)', minWidth:28 }}>{val}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
                {[
                  { label:'MTF Confluence HIGH requise', key:'requireMTFHigh' },
                  { label:'Zone OTE requise',            key:'requireOTE' },
                  { label:'Kill Zone active requise',    key:'requireKillZone' },
                ].map(({ label, key }) => (
                  <label key={key} style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer' }}>
                    <input type="checkbox" checked={(filter as any)[key]}
                      onChange={e => setFilter(f => ({ ...f, [key]: e.target.checked }))} />
                    <span style={{ fontSize:9, color:'var(--text-dim)' }}>{label}</span>
                  </label>
                ))}
              </div>

              <div style={{ marginTop:8 }}>
                <div style={{ fontSize:8, color:'var(--text-muted)', marginBottom:4 }}>PAIRES AUTORISÉES</div>
                <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
                  {SYMBOLS.map(s => {
                    const active = filter.allowedSymbols.includes(s);
                    return (
                      <button key={s} onClick={() => setFilter(f => ({
                        ...f,
                        allowedSymbols: active ? f.allowedSymbols.filter(x => x!==s) : [...f.allowedSymbols, s]
                      }))} style={{ padding:'3px 8px', borderRadius:6, border:`1px solid ${active?'var(--gold)':'var(--border)'}`, background:active?'var(--gold-soft)':'transparent', color:active?'var(--gold)':'var(--text-muted)', fontSize:8, cursor:'pointer', fontWeight:active?700:400 }}>
                        {s.replace('/USD','')}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button onClick={() => setFilter(DEFAULT_FILTER)} style={{ marginTop:8, fontSize:8, padding:'3px 10px', borderRadius:6, border:'1px solid var(--border)', background:'transparent', color:'var(--text-muted)', cursor:'pointer' }}>
                Réinitialiser filtres
              </button>
            </div>
          )}

          {/* ── Boutons manuels ── */}
          {botMode === 'off' && (
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              <button className="btn btn-buy" style={{ fontSize:13, fontWeight:800, minHeight:44 }}
                onClick={() => placeOrder('BUY')} disabled={loading || !connected}>
                {loading?<span className="spinner spinner-sm"/>:'▲ BUY'}
              </button>
              <button className="btn btn-sell" style={{ fontSize:13, fontWeight:800, minHeight:44 }}
                onClick={() => placeOrder('SELL')} disabled={loading || !connected}>
                {loading?<span className="spinner spinner-sm"/>:'▼ SELL'}
              </button>
            </div>
          )}

          {botMode === 'semi' && (
            <div style={{ padding:'10px 12px', background:'var(--gold-soft)', borderRadius:8, border:'1px solid var(--border-gold)', fontSize:10, color:'var(--gold)', textAlign:'center' }}>
              ⚡ En attente du prochain signal qualifié…<br />
              <span style={{ fontSize:8, color:'var(--text-muted)' }}>Conf≥{filter.minConfidence}% · Score≥{filter.minScore} · RR≥{filter.minRR}</span>
            </div>
          )}
          {botMode === 'auto' && (
            <div style={{ padding:'10px 12px', background:'var(--buy-dim)', borderRadius:8, border:'1px solid var(--border-buy)', fontSize:10, color:'var(--buy)', textAlign:'center' }}>
              🤖 Placement automatique actif<br />
              <span style={{ fontSize:8, color:'var(--text-muted)' }}>Filtres: Conf≥{filter.minConfidence}% · Score≥{filter.minScore} · RR≥{filter.minRR} · {autoCount} placés · {skippedCount} ignorés</span>
            </div>
          )}

          {/* ── Close all ── */}
          {connected && openPos > 0 && (
            <button className="btn" onClick={closeAll} disabled={loading} style={{ fontSize:10, fontWeight:700, padding:'7px', background:'var(--sell-dim)', border:'1px solid var(--border-sell)', color:'var(--sell)', borderRadius:8 }}>
              ⚠️ CLOSE ALL ({openPos} position{openPos>1?'s':''})
            </button>
          )}

          {/* ── MT5 non connecté ── */}
          {!connected && (
            <div style={{ padding:'10px 12px', background:'var(--gold-soft)', borderRadius:8, border:'1px solid var(--border-gold)', fontSize:10, color:'var(--gold)', lineHeight:1.7 }}>
              🔌 <strong>MT5 non connecté.</strong><br />
              1. Ouvre MetaTrader 5<br />
              2. Lance l'EA <code>ElJoven_MT5_AutoExecutor</code> sur un chart<br />
              3. Vérifie l'URL backend dans les inputs de l'EA
            </div>
          )}

          {/* ── Tabs : Log bot / Historique MT5 ── */}
          <div>
            <div style={{ display:'flex', gap:0, borderBottom:'1px solid var(--border)', marginBottom:6 }}>
              {(['history','filter'] as const).map(t => (
                <button key={t} onClick={() => setFilterTab(t)} style={{ flex:1, padding:'5px', fontSize:8, fontWeight:700, background:'transparent', border:'none', borderBottom:`2px solid ${filterTab===t?'var(--gold)':'transparent'}`, color:filterTab===t?'var(--gold)':'var(--text-muted)', cursor:'pointer' }}>
                  {t==='history'?`📜 ORDRES MT5 (${history.length})`:`📋 LOG BOT (${botLog.length})`}
                </button>
              ))}
            </div>

            {filterTab === 'history' && history.length > 0 && (
              <div style={{ maxHeight:140, overflowY:'auto', display:'flex', flexDirection:'column', gap:3 }}>
                {history.slice(0,8).map((t, i) => {
                  const ok = t.status === 'FILLED';
                  return (
                    <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'5px 8px', borderRadius:6, background:ok?'var(--buy-dim)':'var(--sell-dim)', border:`1px solid ${ok?'var(--border-buy)':'var(--border-sell)'}` }}>
                      <span style={{ fontSize:9, color:ok?'var(--buy)':'var(--sell)', fontWeight:700 }}>{ok?'✅':'❌'} {t.status}</span>
                      <span style={{ fontSize:8, color:'var(--text-dim)', fontFamily:'Space Mono,monospace' }}>@{t.fillPrice?.toFixed(2)||'—'}</span>
                      <span style={{ fontSize:8, color:'var(--text-muted)' }}>{new Date(t.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {filterTab === 'filter' && (
              <div style={{ maxHeight:140, overflowY:'auto', display:'flex', flexDirection:'column', gap:2 }}>
                {botLog.length === 0 ? (
                  <div style={{ fontSize:9, color:'var(--text-muted)', textAlign:'center', padding:'12px' }}>Aucune activité bot</div>
                ) : botLog.map((l, i) => (
                  <div key={i} style={{ fontSize:8, padding:'3px 8px', borderRadius:5, background:l.ok?'rgba(0,230,118,0.05)':'rgba(255,51,85,0.05)', color:l.ok?'var(--buy)':'var(--sell)', fontFamily:'Space Mono,monospace' }}>
                    <span style={{ opacity:0.5, marginRight:6 }}>{new Date(l.ts).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span>
                    {l.msg}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Paper trades */}
          {paperMode && (
            <div style={{ padding:'8px 10px', borderRadius:8, background:'rgba(147,112,219,0.07)', border:'1px solid rgba(147,112,219,0.25)' }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                <span style={{ fontSize:9, color:'#b39ddb', fontWeight:700 }}>📄 PAPER TRADING</span>
                <span style={{ fontSize:9, fontFamily:'Space Mono,monospace', color: paperPnl >= 0 ? 'var(--buy)' : 'var(--sell)', fontWeight:700 }}>
                  PnL {paperPnl >= 0 ? '+' : ''}{paperPnl}$
                </span>
              </div>
              {paperTrades.length === 0 ? (
                <div style={{ fontSize:8, color:'var(--text-muted)', textAlign:'center' }}>Aucun trade simulé</div>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:3, maxHeight:120, overflowY:'auto' }}>
                  {paperTrades.map((t, i) => (
                    <div key={t.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'4px 6px', borderRadius:5, background: t.closed ? (t.pnl >= 0 ? 'rgba(0,230,118,0.07)' : 'rgba(255,51,85,0.07)') : 'rgba(255,255,255,0.04)', border:`1px solid ${t.closed?(t.pnl>=0?'rgba(0,230,118,0.2)':'rgba(255,51,85,0.2)'):'rgba(255,255,255,0.08)'}` }}>
                      <span style={{ fontSize:8, color: t.side==='BUY'?'var(--buy)':'var(--sell)', fontWeight:700 }}>{t.side} {t.symbol}</span>
                      <span style={{ fontSize:7, fontFamily:'Space Mono,monospace', color:'var(--text-muted)' }}>@{t.entry}</span>
                      {t.closed ? (
                        <span style={{ fontSize:8, fontWeight:700, color: t.pnl >= 0 ? 'var(--buy)' : 'var(--sell)' }}>{t.pnl >= 0 ? '+' : ''}{t.pnl}$</span>
                      ) : (
                        <button onClick={() => closePaperTrade(i, latest?.entry || t.entry)} style={{ fontSize:7, padding:'2px 5px', borderRadius:4, border:'1px solid var(--border)', background:'transparent', color:'var(--text-muted)', cursor:'pointer' }}>CLOSE</button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {feedback && (
            <div style={{ fontSize:10, padding:'7px 10px', borderRadius:8, background:feedback.startsWith('✅')?'var(--buy-dim)':'var(--sell-dim)', border:`1px solid ${feedback.startsWith('✅')?'var(--border-buy)':'var(--border-sell)'}`, color:feedback.startsWith('✅')?'var(--buy)':'var(--sell)', wordBreak:'break-word' as const }}>
              {feedback}
            </div>
          )}
        </div>
      </div>
    </>
  );
}