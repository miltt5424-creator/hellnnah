'use strict';
/**
 * Strategy Engine v4 — El Joven Scalp PRO
 * =========================================
 *
 * Architecture :
 * ┌─────────────────────────────────────────────────────────┐
 * │  DONNÉES  →  ANALYSE  →  SCORE  →  SIGNAL  →  NIVEAUX  │
 * └─────────────────────────────────────────────────────────┘
 *
 * Modules actifs :
 *  ① MTF Confluence  — M1 (entrée) + M15 (confirmation) + H1 (direction)
 *  ② SMC             — BOS, CHoCH, MSS, Order Blocks, FVG, Inducement
 *  ③ ICT             — Kill Zones, OTE 61.8-79%, Premium/Discount, PD Array
 *  ④ HLZ             — Supports/Résistances structurels + niveaux ronds
 *  ⑤ Volume Profile  — POC gate, VWAP gate, vide de volume bloqué
 *  ⑥ DXY Correlation — XAU/EUR/GBP corrélation négative au Dollar
 *  ⑦ Ichimoku Cloud  — Nuage, TK Cross, Chikou confirmation
 *  ⑧ SuperTrend      — Direction + SL dynamique
 *  ⑨ Divergences     — RSI régulière/cachée haussière/baissière
 *  ⑩ Rejection       — Pin Bar, Engulfing, Hammer, Marubozu
 *  ⑪ ADX             — Force de la tendance (≥25 = tendance valide)
 *  ⑫ Fibonacci Auto  — Retracements 23.6/38.2/50/61.8/78.6 sur swing récent
 *  ⑬ Régime marché   — Trending / Range / Compression / Expansion
 *  ⑭ Kelly Criterion — Sizing dynamique f* = (b×p - q) / b
 *
 * Score final : -100 (SELL fort) → 0 (HOLD) → +100 (BUY fort)
 * Seuil signal : ≥ +25 = BUY, ≤ -25 = SELL
 */

const { calcRSI, calcEMA, calcATR, calcMACD, calcBollingerBands,
        calcVWAP, calcStochRSI, calcOBV, calcCVD, calcCVDFull, calcVolumeProfile, swingPoints,
        calcIchimoku, calcSuperTrend, detectDivergences, detectRejectionCandles,
        calcWilliamsR, calcCCI, calcMFI } = require('../utils/indicators');
const logger = require('../utils/logger');

// ── 1. HELPERS ────────────────────────────────────────────────────

function getSwings(candles, lb = 5) {
    return swingPoints(candles, lb);
}

function atr(candles, p = 14) {
    return calcATR(candles, p);
}

// ── 2. SMC — Structure Market Context ────────────────────────────

function analyzeSMC(candles) {
    if (candles.length < 20) return { bias: 'neutral', bos: null, choch: null, mss: null, orderBlocks: [], fvg: [], inducement: null };

    const price = candles[candles.length - 1].close;
    const ATR   = atr(candles);
    const { highs, lows } = getSwings(candles, 5);
    const result = { bias: 'neutral', bos: null, choch: null, mss: null, orderBlocks: [], fvg: [], inducement: null };

    // BOS
    if (highs.length >= 2 && price > highs[highs.length - 2].price) {
        const vol = candles.slice(-20).reduce((a, c) => a + (c.volume || 0), 0) / 20;
        const confirmed = (candles[candles.length - 1].volume || 0) >= vol * 1.1;
        result.bos  = { type: 'bullish', level: highs[highs.length - 2].price, volumeConfirmed: confirmed };
        result.bias = 'bullish';
    }
    if (lows.length >= 2 && price < lows[lows.length - 2].price) {
        const vol = candles.slice(-20).reduce((a, c) => a + (c.volume || 0), 0) / 20;
        const confirmed = (candles[candles.length - 1].volume || 0) >= vol * 1.1;
        result.bos  = { type: 'bearish', level: lows[lows.length - 2].price, volumeConfirmed: confirmed };
        result.bias = 'bearish';
    }

    // CHOCH + MSS
    if (highs.length >= 1 && lows.length >= 1) {
        const lH = highs[highs.length - 1], lL = lows[lows.length - 1];
        if (lL.idx > lH.idx && price < lL.price) result.choch = { type: 'bearish', level: lL.price };
        else if (lH.idx > lL.idx && price > lH.price) result.choch = { type: 'bullish', level: lH.price };
    }
    if (result.choch) {
        const last3 = candles.slice(-3);
        const conf  = result.choch.type === 'bullish'
            ? last3.every(c => c.close > result.choch.level)
            : last3.every(c => c.close < result.choch.level);
        if (conf) result.mss = { type: result.choch.type, level: result.choch.level, confirmed: true };
    }

    // Order Blocks (frais)
    for (let i = candles.length - 10; i < candles.length - 1; i++) {
        if (i < 0) continue;
        const c = candles[i], n = candles[i + 1];
        if (c.close < c.open && n.close > n.open && n.close > c.high)
            result.orderBlocks.push({ type: 'bullish', high: c.high, low: c.low, mid: (c.high + c.low) / 2 });
        if (c.close > c.open && n.close < n.open && n.close < c.low)
            result.orderBlocks.push({ type: 'bearish', high: c.high, low: c.low, mid: (c.high + c.low) / 2 });
    }

    // FVG
    for (let i = 1; i < candles.length - 1; i++) {
        const p = candles[i - 1], n = candles[i + 1];
        if (n.low > p.high) result.fvg.push({ type: 'bullish', top: n.low, bottom: p.high, mid: (n.low + p.high) / 2 });
        if (n.high < p.low) result.fvg.push({ type: 'bearish', top: p.low, bottom: n.high, mid: (p.low + n.high) / 2 });
    }
    result.fvg = result.fvg.slice(-4);

    // Inducement / Liquidity Sweep
    // Equal highs = piège haussier, equal lows = piège baissier
    if (highs.length >= 3) {
        const eq = highs.slice(-3).filter(h => Math.abs(h.price - highs[highs.length - 1].price) < ATR * 0.6);
        if (eq.length >= 2) result.inducement = { type: 'bearish_sweep', level: eq[0].price, desc: 'Equal highs — liquidity pool au-dessus, piège haussier' };
    }
    if (lows.length >= 3) {
        const eq = lows.slice(-3).filter(l => Math.abs(l.price - lows[lows.length - 1].price) < ATR * 0.6);
        if (eq.length >= 2) result.inducement = { type: 'bullish_sweep', level: eq[0].price, desc: 'Equal lows — liquidity pool en-dessous, piège baissier → rebond' };
    }
    // Liquidity sweep réel (wick au-delà du swing puis retour)
    const last = candles[candles.length - 1];
    const recentH = Math.max(...candles.slice(-12).map(c => c.high));
    const recentL = Math.min(...candles.slice(-12).map(c => c.low));
    if (last.high > recentH && last.close < recentH - ATR * 0.1)
        result.liquiditySweep = { type: 'bearish_sweep', level: recentH, desc: 'Stop hunt au-dessus des highs' };
    if (last.low < recentL && last.close > recentL + ATR * 0.1)
        result.liquiditySweep = { type: 'bullish_sweep', level: recentL, desc: 'Stop hunt en-dessous des lows → rebond' };

    return result;
}

// ── 3. ICT — Inner Circle Trader ────────────────────────────────

function analyzeICT(candles) {
    const result = { killZone: null, nextKillZone: null, ote: null, premiumDiscount: null, pdArray: [], liquiditySweep: null };
    const now  = new Date();
    const h    = now.getUTCHours(), m = now.getUTCMinutes();
    const t    = h + m / 60;

    if (t >= 2   && t < 5)  result.killZone = { name: 'Asian KZ',   quality: 1, bias: 'range' };
    if (t >= 7   && t < 10) result.killZone = { name: 'London KZ',  quality: 2, bias: 'directional' };
    if (t >= 8   && t < 9)  result.killZone = { name: 'London Open',quality: 3, bias: 'high_vol' };
    if (t >= 12  && t < 16) result.killZone = { name: 'NY KZ',      quality: 2, bias: 'directional' };
    if (t >= 13  && t < 14) result.killZone = { name: 'NY Open',    quality: 3, bias: 'high_vol' };

    result.nextKillZone = t < 8  ? { name: 'London Open', hoursLeft: +(8 - t).toFixed(1) }
                        : t < 13 ? { name: 'NY Open',     hoursLeft: +(13 - t).toFixed(1) }
                        :          { name: 'London Open demain', hoursLeft: +(32 - t).toFixed(1) };

    if (candles.length >= 20) {
        const price = candles[candles.length - 1].close;
        const ATR   = atr(candles);
        const sw20  = candles.slice(-20);
        const sh = Math.max(...sw20.map(c => c.high));
        const sl = Math.min(...sw20.map(c => c.low));
        const range = sh - sl;
        if (range > 0) {
            const f618 = sh - range * 0.618, f79 = sh - range * 0.79;
            const f618b = sl + range * 0.618, f79b = sl + range * 0.79;
            if (price >= f79 && price <= f618)   result.ote = { level: (f618 + f79) / 2,   type: 'bullish_ote', fib618: f618, fib79: f79 };
            if (price >= f618b && price <= f79b) result.ote = { level: (f618b + f79b) / 2, type: 'bearish_ote', fib618: f618b, fib79: f79b };
        }
    }

    if (candles.length >= 50) {
        const price = candles[candles.length - 1].close;
        const r50   = candles.slice(-50);
        const h50 = Math.max(...r50.map(c => c.high));
        const l50 = Math.min(...r50.map(c => c.low));
        const pct  = (price - l50) / (h50 - l50);
        result.premiumDiscount = {
            zone: pct > 0.618 ? 'premium' : pct < 0.382 ? 'discount' : 'equilibrium',
            pct: +(pct * 100).toFixed(1), equilibrium: (h50 + l50) / 2,
        };
    }

    if (candles.length >= 48) {
        const pd = candles.slice(-48, -24);
        result.pdArray = [
            { label: 'PDH', price: Math.max(...pd.map(c => c.high)) },
            { label: 'PDL', price: Math.min(...pd.map(c => c.low)) },
        ];
    }

    return result;
}

// ── 4. HLZ — High/Low Zones ──────────────────────────────────────

function analyzeHLZ(candles) {
    if (candles.length < 20) return { supports: [], resistances: [], nearestSupport: null, nearestResistance: null };
    const price = candles[candles.length - 1].close;
    const ATR   = atr(candles);
    const zones = [];

    for (let i = 2; i < candles.length - 2; i++) {
        const c = candles[i];
        if (c.high > candles[i-1].high && c.high > candles[i-2].high && c.high > candles[i+1].high && c.high > candles[i+2].high) {
            const tests = candles.filter(x => Math.abs(x.high - c.high) < ATR * 0.5).length;
            zones.push({ type: 'resistance', price: c.high, strength: tests });
        }
        if (c.low < candles[i-1].low && c.low < candles[i-2].low && c.low < candles[i+1].low && c.low < candles[i+2].low) {
            const tests = candles.filter(x => Math.abs(x.low - c.low) < ATR * 0.5).length;
            zones.push({ type: 'support', price: c.low, strength: tests });
        }
    }

    // Niveaux ronds
    const round = price > 10000 ? 1000 : price > 1000 ? 100 : price > 100 ? 10 : 1;
    const nr    = Math.round(price / round) * round;
    if (Math.abs(nr - price) < ATR * 2)
        zones.push({ type: nr > price ? 'resistance' : 'support', price: nr, strength: 5, isRound: true });

    // Merge
    const merged = [];
    for (const z of zones) {
        const ex = merged.find(m => m.type === z.type && Math.abs(m.price - z.price) < ATR);
        if (ex) { ex.price = (ex.price + z.price) / 2; ex.strength += z.strength; }
        else merged.push({ ...z });
    }

    const supports    = merged.filter(z => z.type === 'support'    && z.price < price).sort((a, b) => b.price - a.price);
    const resistances = merged.filter(z => z.type === 'resistance' && z.price > price).sort((a, b) => a.price - b.price);
    return { supports: supports.slice(0, 5), resistances: resistances.slice(0, 5), nearestSupport: supports[0] || null, nearestResistance: resistances[0] || null };
}

// ── 5. VOLUME PROFILE + VWAP GATE ────────────────────────────────
// Règle : n'entre jamais dans un "vide de volume"
// Le prix doit être proche du POC ou d'un High Volume Node (HVN)

function analyzeVolumeProfile(candles, livePrice) {
    const vp   = calcVolumeProfile(candles, 20); // 20 bins pour plus de précision
    const vwap = calcVWAP(candles);
    if (!vp || !vwap) return { poc: null, vwap: null, nearPOC: false, nearVWAP: false, inVolumeVoid: false, gate: 'open' };
    // Si toutes les candles ont volume=0 (Yahoo forex/XAU) → pas de gate void fiable
    const totalVolume = candles.reduce((a, c) => a + (c.volume || 0), 0);
    if (totalVolume === 0) return { poc: vp.poc, vwap: +vwap.toFixed(5), nearPOC: true, nearVWAP: true, inVolumeVoid: false, gate: 'open', noVolume: true };

    const ATR       = atr(candles);
    const nearPOC   = Math.abs(livePrice - vp.poc) < ATR * 1.5;
    const nearVWAP  = Math.abs(livePrice - vwap) < ATR * 1.5;
    // Vide de volume = prix loin du POC ET loin du VWAP → signal bloqué
    const inVoid    = !nearPOC && !nearVWAP && Math.abs(livePrice - vp.poc) > ATR * 3;

    return {
        poc:  vp.poc,
        vwap: +vwap.toFixed(5),
        nearPOC,
        nearVWAP,
        inVolumeVoid: inVoid,
        gate: inVoid ? 'blocked_void' : 'open',
        skew: vp.skew,
    };
}

// ── 6. DXY CORRELATION ───────────────────────────────────────────
// XAU/USD et EUR/USD ont une corrélation NÉGATIVE avec le DXY
// BTC/USD corrélation variable selon régime

function analyzeDXYCorrelation(symbol, dxyCandles) {
    if (!dxyCandles || dxyCandles.length < 20) return { available: false, dxyBias: 'unknown', compatible: true };

    const closes  = dxyCandles.map(c => c.close);
    const ema9    = calcEMA(closes, 9);
    const ema21   = calcEMA(closes, 21);
    const price   = closes[closes.length - 1];
    const dxyBias = ema9 > ema21 ? 'bullish' : 'bearish'; // DXY monte ou baisse

    const DXY_NEGATIVE = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'AUD/USD']; // corrélation négative
    const DXY_POSITIVE = ['USD/JPY', 'USD/CHF']; // corrélation positive

    let compatible = true;
    let reason     = '';

    if (DXY_NEGATIVE.includes(symbol)) {
        // Pour XAU/USD : BUY valide seulement si DXY faible (baissier)
        // SELL valide seulement si DXY fort (haussier)
        compatible = true; // On retourne juste le biais, la décision finale est dans le score
        reason = `DXY ${dxyBias} — ${symbol} corrélation négative`;
    }

    const pctFromMean = ((price - ema21) / ema21) * 100;

    return {
        available: true,
        dxyBias,
        dxyPrice:    +price.toFixed(3),
        dxyEma9:     +ema9.toFixed(3),
        dxyEma21:    +ema21.toFixed(3),
        pctFromMean: +pctFromMean.toFixed(2),
        compatible,
        reason,
        // Signal spécifique pour le caller
        favoursBuy:  DXY_NEGATIVE.includes(symbol) ? dxyBias === 'bearish' : dxyBias === 'bullish',
        favoursSell: DXY_NEGATIVE.includes(symbol) ? dxyBias === 'bullish' : dxyBias === 'bearish',
    };
}

// ── 11. ADX — Average Directional Index ─────────────────────────
// Mesure la FORCE de la tendance (pas sa direction)
// ADX ≥ 25 = tendance valide, < 20 = range/chop

function calcADX(candles, period = 14) {
    if (candles.length < period * 2) return { adx: 0, pdi: 0, mdi: 0, trend: 'weak' };

    const trList = [], pdmList = [], mdmList = [];
    for (let i = 1; i < candles.length; i++) {
        const c = candles[i], p = candles[i - 1];
        const tr  = Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close));
        const pdm = c.high - p.high > p.low - c.low && c.high - p.high > 0 ? c.high - p.high : 0;
        const mdm = p.low - c.low > c.high - p.high && p.low - c.low > 0   ? p.low - c.low  : 0;
        trList.push(tr); pdmList.push(pdm); mdmList.push(mdm);
    }

    // Wilder smoothing
    const smooth = (arr) => {
        let s = arr.slice(0, period).reduce((a, b) => a + b, 0);
        const result = [s];
        for (let i = period; i < arr.length; i++) {
            s = s - s / period + arr[i];
            result.push(s);
        }
        return result;
    };

    const sTR = smooth(trList), sPDM = smooth(pdmList), sMDM = smooth(mdmList);
    const dxList = [];
    for (let i = 0; i < sTR.length; i++) {
        if (sTR[i] === 0) continue;
        const pdi = 100 * sPDM[i] / sTR[i];
        const mdi = 100 * sMDM[i] / sTR[i];
        const dx  = Math.abs(pdi - mdi) / (pdi + mdi || 1) * 100;
        dxList.push({ pdi, mdi, dx });
    }

    const last = dxList[dxList.length - 1] || { pdi: 0, mdi: 0, dx: 0 };
    const adxVal = dxList.slice(-period).reduce((a, b) => a + b.dx, 0) / Math.min(period, dxList.length);

    return {
        adx:   +adxVal.toFixed(1),
        pdi:   +last.pdi.toFixed(1),
        mdi:   +last.mdi.toFixed(1),
        trend: adxVal >= 25 ? (last.pdi > last.mdi ? 'bullish_strong' : 'bearish_strong') : adxVal >= 15 ? 'developing' : 'weak',
        isStrong: adxVal >= 25,
    };
}

// ── 12. FIBONACCI AUTOMATIQUE ────────────────────────────────────
// Trace les retracements Fibonacci sur le dernier swing majeur
// Niveaux : 23.6%, 38.2%, 50%, 61.8%, 78.6%

function calcAutoFibonacci(candles) {
    if (candles.length < 20) return null;
    const { highs, lows } = swingPoints(candles, 5);
    if (highs.length < 1 || lows.length < 1) return null;

    const lastHigh = highs[highs.length - 1];
    const lastLow  = lows[lows.length - 1];
    const price    = candles[candles.length - 1].close;

    // Détecter si le swing récent est haussier ou baissier
    // Haussier = dernier low AVANT dernier high (retrace depuis le bas)
    const isUpswing = lastLow.idx < lastHigh.idx;
    const swingHigh = isUpswing ? lastHigh.price : Math.max(lastHigh.price, lastLow.price);
    const swingLow  = isUpswing ? lastLow.price  : Math.min(lastHigh.price, lastLow.price);
    const range     = swingHigh - swingLow;
    if (range <= 0) return null;

    const fibs = [0.236, 0.382, 0.500, 0.618, 0.786];
    const levels = fibs.map(f => ({
        ratio: f,
        label: `${(f * 100).toFixed(1)}%`,
        price: isUpswing
            ? +(swingHigh - range * f).toFixed(6)   // retracement depuis le haut
            : +(swingLow  + range * f).toFixed(6),  // retracement depuis le bas
    }));

    // Trouver le niveau le plus proche du prix actuel
    const nearest = levels.reduce((a, b) => Math.abs(b.price - price) < Math.abs(a.price - price) ? b : a);
    const ATR_val = calcATR(candles, 14);
    const nearFib = Math.abs(nearest.price - price) < ATR_val * 0.5;

    // Zone OTE ICT = 61.8% à 78.6% (zone d'entrée optimale)
    const ote618 = levels.find(l => l.ratio === 0.618);
    const ote786 = levels.find(l => l.ratio === 0.786);
    const inOTE  = ote618 && ote786 && price >= Math.min(ote618.price, ote786.price) && price <= Math.max(ote618.price, ote786.price);

    return {
        swingHigh: +swingHigh.toFixed(6),
        swingLow:  +swingLow.toFixed(6),
        direction: isUpswing ? 'upswing' : 'downswing',
        levels,
        nearestLevel: nearest,
        nearFib,
        inOTE,
        oteZone: ote618 && ote786 ? { low: +Math.min(ote618.price, ote786.price).toFixed(6), high: +Math.max(ote618.price, ote786.price).toFixed(6) } : null,
    };
}

// ── 13. RÉGIME DE MARCHÉ ─────────────────────────────────────────
// Détecter si le marché est en tendance, range, compression ou expansion
// Adapte le seuil de signal selon le régime

function detectRegime(candles) {
    if (candles.length < 30) return { regime: 'unknown', signal_threshold_mult: 1.0 };
    const closes  = candles.map(c => c.close);
    const ATR_val = calcATR(candles, 14);
    const bb      = calcBollingerBands(closes, 20);
    const bbWidth = (bb.upper - bb.lower) / (bb.middle || 1) * 100;

    // Historique ATR pour comparer la volatilité actuelle
    const atrHistory = candles.slice(-40, -14).map((_, i) =>
        calcATR(candles.slice(i, i + 14), 14)
    );
    const avgHistATR = atrHistory.length > 0
        ? atrHistory.reduce((a, b) => a + b, 0) / atrHistory.length
        : ATR_val;
    const atrRatio = ATR_val / (avgHistATR || ATR_val);

    let regime = 'trending';
    let thresholdMult = 1.0; // multiplicateur du seuil de score (1.0 = normal)
    let desc = '';

    if (bbWidth < 1.2) {
        regime = 'compression';
        thresholdMult = 1.4; // En compression, demander plus de confluence
        desc = '⚡ Squeeze BB — breakout imminent, attendre la direction';
    } else if (atrRatio > 1.6) {
        regime = 'expansion';
        thresholdMult = 0.8; // En expansion, signal plus facile
        desc = '🚀 Expansion de volatilité — tendance forte, suivre';
    } else if (bbWidth < 2.5) {
        regime = 'range';
        thresholdMult = 1.2;
        desc = '📊 Range — acheter support, vendre résistance';
    } else {
        regime = 'trending';
        thresholdMult = 1.0;
        desc = '🎯 Tendance — trader dans la direction principale';
    }

    return { regime, thresholdMult, bbWidth: +bbWidth.toFixed(2), atrRatio: +atrRatio.toFixed(2), description: desc };
}

// ── 7. MTF CONFLUENCE ────────────────────────────────────────────
// Score chaque timeframe indépendamment, puis valide la confluence

function scoreTF(candles) {
    if (!candles || candles.length < 30) return { score: 0, bias: 'neutral', confidence: 0 };
    const closes  = candles.map(c => c.close);
    const price   = closes[closes.length - 1];
    const ema9    = calcEMA(closes, 9);
    const ema21   = calcEMA(closes, 21);
    const ema50   = closes.length >= 50 ? calcEMA(closes, 50) : null;
    const macd    = calcMACD(closes);
    const rsi     = calcRSI(closes, 14);
    const bb      = calcBollingerBands(closes, 20);
    const stoch   = calcStochRSI(closes, 14, 14);
    const obv        = calcOBV(candles);
    const vwap       = calcVWAP(candles);
    const ATR_val    = atr(candles);
    const ichimoku   = candles.length >= 52 ? calcIchimoku(candles) : null;
    const supertrend = candles.length >= 14 ? calcSuperTrend(candles, 10, 3.0) : null;
    const divergence = candles.length >= 40 ? detectDivergences(candles) : { rsi: null, macd: null };
    const rejection  = candles.length >= 5  ? detectRejectionCandles(candles) : null;
    const adx        = candles.length >= 28 ? calcADX(candles, 14) : null;
    const fibonacci  = candles.length >= 20 ? calcAutoFibonacci(candles) : null;
    const regime     = candles.length >= 30 ? detectRegime(candles) : null;
    const williamsR  = candles.length >= 14 ? calcWilliamsR(candles, 14) : null;
    const cci        = candles.length >= 20 ? calcCCI(candles, 20) : null;
    const mfi        = candles.length >= 15 ? calcMFI(candles, 14) : null;
    const cvdFull    = candles.length >= 5  ? calcCVDFull(candles) : null;
    const ema200     = closes.length >= 200 ? calcEMA(closes, 200) : null;

    let bull = 0, bear = 0;

    // EMA triple alignement
    if (ema50 && ema9 > ema21 && ema21 > ema50) { bull += 3; }
    else if (ema50 && ema9 < ema21 && ema21 < ema50) { bear += 3; }
    else if (ema9 > ema21) { bull += 1; }
    else { bear += 1; }

    // Prix vs EMA50
    if (ema50) { if (price > ema50) bull += 1; else bear += 1; }

    // MACD
    if (macd.histogram > 0 && macd.macdLine > macd.signalLine) { bull += 2; }
    else if (macd.histogram > 0) { bull += 1; }
    else if (macd.histogram < 0 && macd.macdLine < macd.signalLine) { bear += 2; }
    else { bear += 1; }

    // RSI
    if (rsi < 30)      { bull += 3; }
    else if (rsi < 45) { bull += 1; }
    else if (rsi > 70) { bear += 3; }
    else if (rsi > 55) { bear += 1; }

    // BB
    const bbR = bb.upper - bb.lower;
    if (bbR > 0) {
        const pos = (price - bb.lower) / bbR;
        if (pos < 0.15)      { bull += 2; }
        else if (pos < 0.35) { bull += 1; }
        else if (pos > 0.85) { bear += 2; }
        else if (pos > 0.65) { bear += 1; }
    }

    // StochRSI
    if (stoch?.signal === 'BULLISH') { bull += 2; }
    else if (stoch?.signal === 'BEARISH') { bear += 2; }

    // VWAP
    if (vwap) {
        if (price > vwap * 1.001) bull += 1;
        else if (price < vwap * 0.999) bear += 1;
    }

    // OBV
    if (obv?.trend === 'UP') bull += 1;
    else if (obv?.trend === 'DOWN') bear += 1;

    // CVD full (delta récent)
    if (cvdFull?.trend === 'UP')   bull += 1;
    if (cvdFull?.trend === 'DOWN') bear += 1;

    // Williams %R
    if (williamsR !== null) {
        if (williamsR <= -80) bull += 2;       // survente
        else if (williamsR <= -60) bull += 1;
        else if (williamsR >= -20) bear += 2;  // surachat
        else if (williamsR >= -40) bear += 1;
    }

    // MFI
    if (mfi !== null) {
        if (mfi < 20) bull += 2;
        else if (mfi < 35) bull += 1;
        else if (mfi > 80) bear += 2;
        else if (mfi > 65) bear += 1;
    }

    // Ichimoku (poids fort — indicateur institutionnel)
    if (ichimoku) {
        if (ichimoku.bias === 'bullish')  { bull += 3; }
        if (ichimoku.bias === 'bearish')  { bear += 3; }
        if (ichimoku.aboveCloud)          { bull += 1; }
        if (ichimoku.belowCloud)          { bear += 1; }
        if (ichimoku.tkCross === 'bullish') { bull += 2; }
        if (ichimoku.tkCross === 'bearish') { bear += 2; }
    }

    // SuperTrend
    if (supertrend) {
        if (supertrend.direction === 'bullish') { bull += 2; }
        if (supertrend.direction === 'bearish') { bear += 2; }
        if (supertrend.crossed && supertrend.direction === 'bullish') { bull += 2; } // Crossover = signal fort
        if (supertrend.crossed && supertrend.direction === 'bearish') { bear += 2; }
    }

    // Divergences (signal de retournement haute précision — poids très fort)
    if (divergence?.rsi) {
        if (divergence.rsi.type === 'bullish_regular') { bull += 4; }
        if (divergence.rsi.type === 'bearish_regular') { bear += 4; }
        if (divergence.rsi.type === 'bullish_hidden')  { bull += 2; } // continuation
        if (divergence.rsi.type === 'bearish_hidden')  { bear += 2; }
    }

    // Rejection Candles (confirmation déclencheur)
    if (rejection) {
        for (const r of rejection) {
            if (r.signal === 'BUY'  && r.strength === 'high')   { bull += 3; }
            if (r.signal === 'SELL' && r.strength === 'high')   { bear += 3; }
            if (r.signal === 'BUY'  && r.strength === 'medium') { bull += 1; }
            if (r.signal === 'SELL' && r.strength === 'medium') { bear += 1; }
        }
    }

    // ADX — Force de la tendance
    // Si ADX fort, amplifier le signal dominant. Si faible, réduire.
    if (adx) {
        if (adx.isStrong && adx.trend === 'bullish_strong') { bull += 2; }
        if (adx.isStrong && adx.trend === 'bearish_strong') { bear += 2; }
        if (adx.trend === 'weak') {
            // Marché en chop → réduire les deux côtés
            bull = Math.round(bull * 0.8);
            bear = Math.round(bear * 0.8);
        }
    }

    // Fibonacci — OTE zone = zone d'entrée optimale ICT
    if (fibonacci?.inOTE) {
        if (fibonacci.direction === 'upswing') { bull += 2; } // retracement haussier en zone OTE
        if (fibonacci.direction === 'downswing') { bear += 2; }
    }
    if (fibonacci?.nearFib) {
        // Prix au niveau Fibonacci = zone de réaction probable
        if (fibonacci.nearestLevel?.ratio >= 0.5 && bull > bear) bull += 1;
        if (fibonacci.nearestLevel?.ratio >= 0.5 && bear > bull) bear += 1;
    }

    const total = bull + bear;
    const bias  = bull > bear + 2 ? 'bullish' : bear > bull + 2 ? 'bearish' : 'neutral';
    const score = total > 0 ? Math.round((bull - bear) / total * 100) : 0;
    const confidence = total > 0 ? Math.round(Math.max(bull, bear) / total * 100) : 50;

    return {
        score, bias, bull, bear, confidence,
        // Indicateurs de base (pour IndicatorsPanel)
        rsi:          +rsi.toFixed(1),
        ema9:         +ema9.toFixed(5),
        ema21:        +ema21.toFixed(5),
        ema50:        ema50 ? +ema50.toFixed(5) : null,
        atr:          +ATR_val.toFixed(5),
        macdLine:     +macd.macdLine.toFixed(6),
        macdSignal:   +macd.signalLine.toFixed(6),
        macdHistogram:+macd.histogram.toFixed(6),
        bbUpper:      +bb.upper.toFixed(5),
        bbMiddle:     +bb.middle.toFixed(5),
        bbLower:      +bb.lower.toFixed(5),
        stochRsi:     stoch ? { k: +stoch.k.toFixed(1), d: +stoch.d.toFixed(1), signal: stoch.signal } : null,
        vwap:         vwap ? +vwap.toFixed(5) : null,
        obv:          obv     ? { trend: obv.trend } : null,
        cvd:          cvdFull ? { value: cvdFull.value, trend: cvdFull.trend, delta: cvdFull.delta } : null,
        williamsR:    williamsR,
        cci:          cci,
        mfi:          mfi,
        ema200:       ema200 ? +ema200.toFixed(5) : null,
        // Indicateurs avancés
        ichimoku:   ichimoku   ? { bias: ichimoku.bias, aboveCloud: ichimoku.aboveCloud, belowCloud: ichimoku.belowCloud, tkCross: ichimoku.tkCross, cloudTop: ichimoku.cloudTop, cloudBottom: ichimoku.cloudBottom } : null,
        supertrend: supertrend ? { direction: supertrend.direction, value: supertrend.value, crossed: supertrend.crossed, slLevel: supertrend.slLevel } : null,
        divergence: divergence?.rsi ? { type: divergence.rsi.type, desc: divergence.rsi.desc } : null,
        rejection:  rejection  ? rejection.filter(r => r.strength === 'high').slice(0, 2) : null,
        adx:        adx        ? { adx: adx.adx, pdi: adx.pdi, mdi: adx.mdi, trend: adx.trend, isStrong: adx.isStrong } : null,
        fibonacci:  fibonacci  ? { direction: fibonacci.direction, inOTE: fibonacci.inOTE, nearFib: fibonacci.nearFib, nearestLevel: fibonacci.nearestLevel, oteZone: fibonacci.oteZone, levels: fibonacci.levels } : null,
        regime:     regime     ? { regime: regime.regime, description: regime.description } : null,
    };
}

function analyzeMTF(m1Candles, m15Candles, h1Candles) {
    const tf1  = scoreTF(m1Candles);
    const tf15 = m15Candles ? scoreTF(m15Candles) : null;
    const tf60 = h1Candles  ? scoreTF(h1Candles)  : null;

    const hasM15 = tf15 && tf15.bias !== 'neutral';
    const hasH1  = tf60 && tf60.bias !== 'neutral';

    // Poids adaptatifs selon les TF disponibles
    // Quand H1 absent : M1 pèse plus, seuils de confluence ajustés
    let bullScore = tf1.bias === 'bullish' ? 2 : 0;
    let bearScore = tf1.bias === 'bearish' ? 2 : 0;
    if (hasM15) { bullScore += tf15.bias === 'bullish' ? 2 : 0; bearScore += tf15.bias === 'bearish' ? 2 : 0; }
    if (hasH1)  { bullScore += tf60.bias === 'bullish' ? 3 : 0; bearScore += tf60.bias === 'bearish' ? 3 : 0; }

    // Seuils adaptatifs selon les TF disponibles
    const maxScore  = 2 + (hasM15 ? 2 : 0) + (hasH1 ? 3 : 0);
    const alignedThr = maxScore >= 7 ? 5 : maxScore >= 4 ? 3 : 2;
    const partialThr = maxScore >= 7 ? 3 : 2;

    const aligned   = bullScore >= alignedThr || bearScore >= alignedThr;
    const partial   = bullScore >= partialThr  || bearScore >= partialThr;
    const direction = bullScore > bearScore ? 'bullish' : bearScore > bullScore ? 'bearish' : 'neutral';
    const strength  = aligned ? 'strong' : partial ? 'moderate' : 'weak';

    // counterTrend uniquement si H1 disponible et fiable
    const counterTrend = hasH1 && (
        (tf60.bias === 'bullish' && tf1.bias === 'bearish') ||
        (tf60.bias === 'bearish' && tf1.bias === 'bullish')
    );

    return {
        direction, strength, aligned, counterTrend,
        bullScore, bearScore, maxScore,
        hasM15, hasH1,
        tf1, tf15: tf15 || { bias:'neutral', score:0, confidence:0 }, tf60: tf60 || { bias:'neutral', score:0, confidence:0 },
        confluence: aligned ? 'HIGH' : partial ? 'MEDIUM' : 'LOW',
    };
}

// ── 8. SL/TP STRUCTURELS ─────────────────────────────────────────

function computeStructuralLevels(candles, direction, livePrice, hlz) {
    const ATR_val = atr(candles);
    const { highs, lows } = getSwings(candles, 5);
    let sl, tp;

    if (direction === 'BUY') {
        // SL = dernier swing low sous le prix
        const validLows = lows.filter(s => s.price < livePrice).sort((a, b) => b.idx - a.idx);
        sl = validLows.length > 0
            ? validLows[0].price - ATR_val * 0.25
            : livePrice - ATR_val * 1.5;

        // TP = prochain swing high OU résistance HLZ
        const slDist = Math.abs(livePrice - sl);
        const minTP  = livePrice + slDist * 1.8;
        const validHighs = highs.filter(s => s.price > minTP).sort((a, b) => a.price - b.price);
        const hlzTP = hlz.nearestResistance?.price;

        if (validHighs.length > 0 && hlzTP) {
            tp = Math.min(validHighs[0].price, hlzTP) - ATR_val * 0.1;
        } else if (validHighs.length > 0) {
            tp = validHighs[0].price - ATR_val * 0.1;
        } else if (hlzTP && hlzTP > minTP) {
            tp = hlzTP - ATR_val * 0.1;
        } else {
            tp = livePrice + slDist * 2.0;
        }
    } else {
        // SL = dernier swing high au-dessus du prix
        const validHighs = highs.filter(s => s.price > livePrice).sort((a, b) => b.idx - a.idx);
        sl = validHighs.length > 0
            ? validHighs[0].price + ATR_val * 0.25
            : livePrice + ATR_val * 1.5;

        const slDist = Math.abs(sl - livePrice);
        const minTP  = livePrice - slDist * 1.8;
        const validLows = lows.filter(s => s.price < minTP).sort((a, b) => b.price - a.price);
        const hlzTP = hlz.nearestSupport?.price;

        if (validLows.length > 0 && hlzTP) {
            tp = Math.max(validLows[0].price, hlzTP) + ATR_val * 0.1;
        } else if (validLows.length > 0) {
            tp = validLows[0].price + ATR_val * 0.1;
        } else if (hlzTP && hlzTP < minTP) {
            tp = hlzTP + ATR_val * 0.1;
        } else {
            tp = livePrice - slDist * 2.0;
        }
    }

    // Validation direction
    if (direction === 'BUY'  && sl >= livePrice) sl = livePrice - ATR_val * 1.5;
    if (direction === 'BUY'  && tp <= livePrice) tp = livePrice + Math.abs(livePrice - sl) * 2.0;
    if (direction === 'SELL' && sl <= livePrice) sl = livePrice + ATR_val * 1.5;
    if (direction === 'SELL' && tp >= livePrice) tp = livePrice - Math.abs(sl - livePrice) * 2.0;

    const slDist = Math.abs(livePrice - sl);
    const tpDist = Math.abs(tp - livePrice);
    const rr     = slDist > 0 ? +(tpDist / slDist).toFixed(2) : 0;

    return { sl, tp, rr, atr: ATR_val };
}

// ── 9. KELLY CRITERION ───────────────────────────────────────────
// Calcule la taille de position optimale basée sur la probabilité estimée
// f* = (bp - q) / b  où b = RR, p = prob win, q = 1-p

function kellySize(confidence, rr, maxRisk = 2.0) {
    const p = confidence / 100;        // probabilité de gain
    const q = 1 - p;                   // probabilité de perte
    const b = rr;                      // ratio gain/perte
    const kelly = (b * p - q) / b;    // Kelly complet
    const halfKelly = kelly / 2;       // Half-Kelly (plus conservateur)

    // Clamper entre 0.1% et maxRisk%
    const size = Math.max(0.1, Math.min(maxRisk, +(halfKelly * 100).toFixed(2)));
    return {
        kellyFull:  +(kelly * 100).toFixed(2),
        kellySafe:  size,
        riskNote: size >= 1.5 ? 'Taille max — signal fort' : size >= 0.8 ? 'Taille modérée' : 'Taille réduite — signal faible',
    };
}

// ── 10. SCORE COMPOSITE FINAL ────────────────────────────────────

function computeCompositeScore(mtf, smc, ict, hlz, volProfile, dxy, symbol) {
    let score = 0;
    const signals = [];

    // MTF (poids maximum)
    if (mtf.direction === 'bullish') {
        if (mtf.strength === 'strong')   { score += 35; signals.push('MTF confluence forte ↑ (3TF)'); }
        else if (mtf.strength === 'moderate') { score += 20; signals.push('MTF confluence modérée ↑'); }
        else { score += 8; }
    } else if (mtf.direction === 'bearish') {
        if (mtf.strength === 'strong')   { score -= 35; signals.push('MTF confluence forte ↓ (3TF)'); }
        else if (mtf.strength === 'moderate') { score -= 20; signals.push('MTF confluence modérée ↓'); }
        else { score -= 8; }
    }

    // Contre-tendance → fort malus
    if (mtf.counterTrend) { score = Math.round(score * 0.4); signals.push('⚠️ CONTRE-TENDANCE H1 — signal réduit 60%'); }

    // SMC
    if (smc.bias === 'bullish') { score += 15; signals.push('SMC bias haussier'); }
    if (smc.bias === 'bearish') { score -= 15; signals.push('SMC bias baissier'); }
    if (smc.bos?.type === 'bullish' && smc.bos.volumeConfirmed) { score += 12; signals.push('BOS haussier ✅ volume'); }
    if (smc.bos?.type === 'bearish' && smc.bos.volumeConfirmed) { score -= 12; signals.push('BOS baissier ✅ volume'); }
    if (smc.mss?.type === 'bullish') { score += 18; signals.push('MSS haussier confirmé'); }
    if (smc.mss?.type === 'bearish') { score -= 18; signals.push('MSS baissier confirmé'); }
    if (smc.inducement?.type === 'bullish_sweep') { score += 20; signals.push('Liquidity Sweep baissier → rebond haussier'); }
    if (smc.inducement?.type === 'bearish_sweep') { score -= 20; signals.push('Liquidity Sweep haussier → retournement baissier'); }
    if (smc.liquiditySweep?.type === 'bullish_sweep') { score += 22; signals.push('Stop hunt bas → rebond imminent'); }
    if (smc.liquiditySweep?.type === 'bearish_sweep') { score -= 22; signals.push('Stop hunt haut → chute imminente'); }

    // ICT
    if (ict.killZone?.quality === 3) { score += 12; signals.push(`${ict.killZone.name} — haute volatilité`); }
    if (ict.killZone?.quality === 1) { score = Math.round(score * 0.7); signals.push('Session asiatique — signal réduit 30%'); }
    if (ict.ote?.type === 'bullish_ote') { score += 15; signals.push('ICT OTE zone haussière (61.8-79%)'); }
    if (ict.ote?.type === 'bearish_ote') { score -= 15; signals.push('ICT OTE zone baissière'); }
    if (ict.premiumDiscount?.zone === 'discount') { score += 10; signals.push('Zone Discount — favorable BUY'); }
    if (ict.premiumDiscount?.zone === 'premium')  { score -= 10; signals.push('Zone Premium — favorable SELL'); }

    // HLZ
    const price = 0; // placeholder, comparaison relative
    if (hlz.nearestSupport)    { score += 8;  signals.push(`Support HLZ ${hlz.nearestSupport.price.toFixed(2)}`); }
    if (hlz.nearestResistance) { score -= 8;  signals.push(`Résistance HLZ ${hlz.nearestResistance.price.toFixed(2)}`); }

    // Volume Profile gate (uniquement si volume réel disponible)
    if (volProfile.inVolumeVoid && !volProfile.noVolume) { score = Math.round(score * 0.3); signals.push('⚠️ VIDE DE VOLUME — signal réduit 70%'); }
    if (volProfile.nearPOC)  { score += 10; signals.push('Prix au POC — niveau institutionnel'); }
    if (volProfile.nearVWAP) { score += 6;  signals.push('Prix au VWAP'); }

    // DXY Correlation
    if (dxy?.available) {
        if (dxy.favoursBuy)  { score += 10; signals.push(`DXY ${dxy.dxyBias} → favorable ${symbol} BUY`); }
        if (dxy.favoursSell) { score -= 10; signals.push(`DXY ${dxy.dxyBias} → favorable ${symbol} SELL`); }
    }

    // ADX H1 — si tendance forte sur H1, amplifier le score MTF
    const h1ADX = mtf.tf60?.adx;
    if (h1ADX?.isStrong) {
        if (h1ADX.trend === 'bullish_strong' && score > 0) { score = Math.round(score * 1.2); signals.push(`ADX H1 ${h1ADX.adx} — tendance haussière forte`); }
        if (h1ADX.trend === 'bearish_strong' && score < 0) { score = Math.round(score * 1.2); signals.push(`ADX H1 ${h1ADX.adx} — tendance baissière forte`); }
    } else if (h1ADX?.trend === 'weak') {
        score = Math.round(score * 0.7);
        signals.push('ADX faible — marché sans tendance, signal réduit');
    }

    // Fibonacci M1 — OTE zone = bonus entrée précise
    const m1Fib = mtf.tf1?.fibonacci;
    if (m1Fib?.inOTE) {
        if (score > 0) { score += 8; signals.push('Prix en zone OTE Fibonacci (61.8-78.6%) — entrée optimale'); }
        if (score < 0) { score -= 8; }
    }

    // Régime M1
    const m1Regime = mtf.tf1?.regime;
    if (m1Regime?.regime === 'compression') { score = Math.round(score * 0.6); signals.push('⚡ Squeeze — attendre breakout avant entrée'); }
    if (m1Regime?.regime === 'expansion')   { score = Math.round(score * 1.15); signals.push('🚀 Expansion — momentum fort'); }

    // ── VETO SYSTEM — conditions qui annulent le signal indépendamment du score ──
    const vetoes = [];

    // VETO 1 : H1 contre-tendance forte — uniquement si H1 réellement disponible
    const h1Bias = mtf.hasH1 ? mtf.tf60?.bias : null;
    if (h1Bias === 'bearish' && score > 0 && score < 42) {
        vetoes.push('⛔ VETO : H1 baissier — BUY faible annulé');
        score = 0;
    }
    if (h1Bias === 'bullish' && score < 0 && score > -42) {
        vetoes.push('⛔ VETO : H1 haussier — SELL faible annulé');
        score = 0;
    }

    // VETO 2 : ADX trop faible sur M1 ET H1 → pas de tendance → pas de signal
    const m1ADX = mtf.tf1?.adx?.adx || 0;
    const h1ADX_val = mtf.tf60?.adx?.adx || 0;
    if (m1ADX < 12 && h1ADX_val < 12) {
        vetoes.push('⛔ VETO : ADX M1+H1 très faible — marché sans direction');
        score = Math.round(score * 0.55);
    }

    // VETO 3 : Ichimoku H1 contre le signal
    const h1Ichi = mtf.tf60?.ichimoku;
    if (h1Ichi) {
        if (h1Ichi.bias === 'bearish' && score > 0 && score < 50) {
            vetoes.push('⛔ VETO : Ichimoku H1 sous le nuage — BUY risqué');
            score = Math.round(score * 0.5);
        }
        if (h1Ichi.bias === 'bullish' && score < 0 && score > -50) {
            vetoes.push('⛔ VETO : Ichimoku H1 au-dessus du nuage — SELL risqué');
            score = Math.round(score * 0.5);
        }
    }

    // VETO 4 : SuperTrend H1 contre le signal
    const h1ST = mtf.tf60?.supertrend;
    if (h1ST) {
        if (h1ST.direction === 'bearish' && score > 0 && score < 45) {
            score = Math.round(score * 0.6);
            vetoes.push('⛔ SuperTrend H1 baissier — BUY réduit');
        }
        if (h1ST.direction === 'bullish' && score < 0 && score > -45) {
            score = Math.round(score * 0.6);
            vetoes.push('⛔ SuperTrend H1 haussier — SELL réduit');
        }
    }

    // VETO 5 : Pas de confluence MTF du tout (3 TF en désaccord)
    // VETO confluence LOW uniquement si on a les 3 TF (sinon MTF partiel = normal pour forex)
    if (mtf.confluence === 'LOW' && mtf.hasH1 && mtf.hasM15 && Math.abs(score) < 38) {
        score = Math.round(score * 0.65);
        vetoes.push('⛔ MTF confluence LOW (3TF) — signal réduit');
    }

    if (vetoes.length > 0) signals.push(...vetoes);

    return { score: Math.max(-100, Math.min(100, Math.round(score))), signals };
}

// ── 15. STRUCTURE DE MARCHÉ ─────────────────────────────────────
// HH/HL = tendance haussière, LH/LL = baissière

function analyzeMarketStructure(candles) {
    if (candles.length < 20) return { trend: 'undetermined', strength: 'weak', hhCount: 0, hlCount: 0, llCount: 0, lhCount: 0 };
    const { highs, lows } = getSwings(candles, 5);
    if (highs.length < 2 || lows.length < 2) return { trend: 'undetermined', strength: 'weak' };

    const rH = highs.slice(-4), rL = lows.slice(-4);
    const hhCount = rH.slice(1).filter((h, i) => h.price > rH[i].price).length;
    const hlCount = rL.slice(1).filter((l, i) => l.price > rL[i].price).length;
    const llCount = rL.slice(1).filter((l, i) => l.price < rL[i].price).length;
    const lhCount = rH.slice(1).filter((h, i) => h.price < rH[i].price).length;

    let trend = 'range', strength = 'weak';
    if (hhCount >= 2 && hlCount >= 2)      { trend = 'bullish'; strength = 'strong'; }
    else if (llCount >= 2 && lhCount >= 2) { trend = 'bearish'; strength = 'strong'; }
    else if (hhCount >= 1 && hlCount >= 1) { trend = 'bullish'; strength = 'moderate'; }
    else if (llCount >= 1 && lhCount >= 1) { trend = 'bearish'; strength = 'moderate'; }

    const lastHigh = highs[highs.length - 1] || null;
    const lastLow  = lows[lows.length - 1]   || null;
    return { trend, strength, hhCount, hlCount, llCount, lhCount, lastHigh, lastLow };
}

// ── EXPORT PRINCIPAL ──────────────────────────────────────────────

async function analyze(candles, symbol, options = {}) {
    if (!candles || candles.length < 20) return null;
    const { m15Candles, h1Candles, dxyCandles, livePrice } = options;
    const price = livePrice || candles[candles.length - 1].close;

    const smc       = analyzeSMC(candles);
    const ict       = analyzeICT(candles);
    const hlz       = analyzeHLZ(candles);
    const volProfile= analyzeVolumeProfile(candles, price);
    const dxy       = analyzeDXYCorrelation(symbol, dxyCandles || null);
    const mtf       = analyzeMTF(candles, m15Candles || candles, h1Candles || candles);

    const { score, signals } = computeCompositeScore(mtf, smc, ict, hlz, volProfile, dxy, symbol);

    // Détermination de la direction finale
    const direction = score >= 28 ? 'BUY' : score <= -28 ? 'SELL' : 'HOLD';

    // SL/TP structurels (seulement si signal)
    let levels = null;
    if (direction !== 'HOLD') {
        // Entrée optimale : Order Block ou OTE si disponible, sinon prix live
        let entryPrice = price;
        const ob = smc.orderBlocks?.find(o => o.type === (direction === 'BUY' ? 'bullish' : 'bearish'));
        const oteZone = ict.ote;
        if (oteZone && oteZone.type === (direction === 'BUY' ? 'bullish_ote' : 'bearish_ote')) {
            // Entrée au milieu de la zone OTE
            entryPrice = oteZone.level;
        } else if (ob) {
            // Entrée au milieu de l'Order Block
            entryPrice = ob.mid;
        }
        // Ne pas s'éloigner de plus de 0.3% du prix live (sinon limite order)
        const maxDrift = price * 0.003;
        if (Math.abs(entryPrice - price) > maxDrift) entryPrice = price;
        levels = computeStructuralLevels(candles, direction, entryPrice, hlz);
    }

    // Compter les confirmations majeures (indicateurs institutionnels clés)
    let majorConfirmations = 0;
    if (mtf.aligned) majorConfirmations++;                                    // 3 TF alignés
    if (smc.bos?.volumeConfirmed) majorConfirmations++;                       // BOS avec volume
    if (smc.mss?.type === (direction === 'BUY' ? 'bullish' : 'bearish')) majorConfirmations++; // MSS
    if (smc.liquiditySweep) majorConfirmations++;                             // Liquidity sweep
    if (ict.ote) majorConfirmations++;                                        // Zone OTE
    if (ict.killZone?.quality >= 2) majorConfirmations++;                     // Kill zone active
    const m1Adx = mtf.tf1?.adx;
    if (m1Adx?.isStrong) majorConfirmations++;                               // ADX fort M1
    const m1Div = mtf.tf1?.divergence?.rsi;
    if (m1Div?.type?.includes('regular')) majorConfirmations++;              // Divergence RSI

    // Si moins de 2 confirmations majeures → on réduit le score fortement
    if (majorConfirmations < 2 && direction !== 'HOLD') {
        // Pas assez de confluence institutionnelle
    }

    // Confidence basée sur MTF + score + confirmations majeures
    const baseConf  = Math.min(95, Math.abs(score) * 0.6 + 20);
    const mtfBonus  = mtf.aligned ? 15 : mtf.strength === 'moderate' ? 8 : 0;
    const confBonus = Math.min(15, majorConfirmations * 3);
    const confidence= Math.min(95, Math.round(baseConf + mtfBonus + confBonus));

    // Kelly sizing
    const kelly = levels ? kellySize(confidence, levels.rr) : null;

    // Structure de marché sur chaque TF
    const structM1  = analyzeMarketStructure(candles);
    const structH1  = h1Candles ? analyzeMarketStructure(h1Candles) : null;

    return {
        direction, score, confidence, signals, majorConfirmations,
        levels,   // { sl, tp, rr, atr }
        kelly,    // { kellySafe, riskNote }
        marketStructure: { m1: structM1, h1: structH1 },
        mtf:  {
            direction: mtf.direction, strength: mtf.strength, confluence: mtf.confluence, counterTrend: mtf.counterTrend,
            tf1: mtf.tf1, tf15: mtf.tf15, tf60: mtf.tf60,
            // Indicateurs avancés M1 (les plus pertinents pour le timing d'entrée)
            ichimoku:   mtf.tf1.ichimoku,
            supertrend: mtf.tf1.supertrend,
            divergence: mtf.tf1.divergence,
            rejection:  mtf.tf1.rejection,
            adx:        mtf.tf1.adx,
            fibonacci:  mtf.tf1.fibonacci,
            regime:     mtf.tf1.regime,
        },
        smc:  { bias: smc.bias, bos: smc.bos, choch: smc.choch, mss: smc.mss, orderBlocks: smc.orderBlocks.slice(0, 3), fvg: smc.fvg.slice(0, 3), inducement: smc.inducement, liquiditySweep: smc.liquiditySweep },
        ict:  { killZone: ict.killZone, nextKillZone: ict.nextKillZone, ote: ict.ote, premiumDiscount: ict.premiumDiscount, pdArray: ict.pdArray },
        hlz:  { nearestSupport: hlz.nearestSupport, nearestResistance: hlz.nearestResistance, supports: hlz.supports.slice(0, 3), resistances: hlz.resistances.slice(0, 3) },
        volProfile,
        dxy,
    };
}

module.exports = { analyze, analyzeSMC, analyzeICT, analyzeHLZ, analyzeVolumeProfile, analyzeDXYCorrelation, analyzeMTF, computeStructuralLevels, kellySize, scoreTF, calcADX, calcAutoFibonacci, detectRegime, analyzeMarketStructure };