'use strict';
/**
 * AutoSignal v8 — El Joven Scalp PRO
 * =====================================
 * Pipeline complet :
 *   1. Prix live Binance (< 5s)
 *   2. Candles M1 + M15 + H1 (MTF)
 *   3. DXY pour XAU/EUR/GBP
 *   4. strategyEngine.analyze() → MTF + SMC + ICT + HLZ + VolProfile + DXY
 *   5. SL/TP structurels (swing réel)
 *   6. Kelly Criterion → taille de position recommandée
 *   7. Volume Profile gate → bloque si vide de volume
 *   8. Cooldown 15min par symbol+direction
 *   9. Émission immédiate, pas de lock
 */

const logger = require('../utils/logger');
const { analyze } = require('../services/strategyEngine');
const telegram = require('../services/telegram');

const clients     = new Set();
let   scheduler   = null;
let   isRunning   = false;
const COOLDOWN_MS = 15 * 60 * 1000;
const cooldown    = {};
const lastSignals = {};

const SYMBOLS = ['BTC/USD', 'ETH/USD', 'XAU/USD', 'EUR/USD', 'GBP/USD'];
const DXY_SYMBOLS = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'AUD/USD'];

// Décimales par actif
const DECIMALS = { 'BTC/USD': 0, 'ETH/USD': 2, 'XAU/USD': 2, 'EUR/USD': 5, 'GBP/USD': 5, default: 2 };

function broadcastSignal(sig) {
    const payload = JSON.stringify({ type: 'auto_signal', ...sig });
    let sent = 0;
    for (const ws of clients) {
        if (ws.readyState === ws.OPEN) {
            try { ws.send(payload); sent++; } catch { /* ignore */ }
        }
    }
    return sent;
}

async function generateAndBroadcast() {
    const { getPriceHistory, getPrice } = require('../services/priceAggregator');
    const now = Date.now();

    // Fetch DXY une fois pour tous les symbols corrélés
    let dxyCandles = null;
    try {
        const dxyHist = await getPriceHistory('USD/CHF', '1min', 60); // proxy DXY via USD/CHF
        dxyCandles = dxyHist?.candles || null;
    } catch { /* DXY optionnel */ }

    for (const symbol of SYMBOLS) {
        try {
            // ── 1. Prix live ──────────────────────────────────────
            const priceData = await getPrice(symbol);
            const livePrice = priceData?.price;
            if (!livePrice || livePrice <= 0) continue;

            // ── 2. Données synthétiques = skip ────────────────────
            const m1Hist = await getPriceHistory(symbol, '1min', 120);
            if (!m1Hist?.candles?.length || m1Hist.source === 'synthetic') continue;
            const m1Candles = m1Hist.candles;

            // ── 3. MTF candles ────────────────────────────────────
            let m15Candles = null, h1Candles = null;
            try { m15Candles = (await getPriceHistory(symbol, '15min', 100))?.candles; } catch {}
            try { h1Candles  = (await getPriceHistory(symbol, '1h',    100))?.candles; } catch {}

            // ── 4. DXY pour actifs corrélés ───────────────────────
            const useDXY = DXY_SYMBOLS.includes(symbol) ? dxyCandles : null;

            // ── 5. Analyse complète ───────────────────────────────
            // Validation par intervalle entre candles
            const m1Interval  = m1Candles.length  >= 2 ? m1Candles[1].time  - m1Candles[0].time  : 60;
            const m15Interval = m15Candles && m15Candles.length >= 2 ? m15Candles[1].time - m15Candles[0].time : 0;
            const h1Interval  = h1Candles  && h1Candles.length  >= 2 ? h1Candles[1].time  - h1Candles[0].time  : 0;
            const m15Valid = m15Candles && m15Candles.length > 10 && m15Interval >= 300;
            const h1Valid  = h1Candles  && h1Candles.length  > 10 && h1Interval  >= 1800;
            const analysis = await analyze(m1Candles, symbol, {
                m15Candles: m15Valid ? m15Candles : null,
                h1Candles:  h1Valid  ? h1Candles  : null,
                dxyCandles: useDXY,
                livePrice,
            });

            if (!analysis || analysis.direction === 'HOLD') continue;

            const { direction, score, confidence, signals, levels, kelly, mtf, smc, ict, volProfile, dxy } = analysis;

            // ── 6. Volume Profile gate ────────────────────────────
            if (volProfile?.gate === 'blocked_void') {
                logger.info(`⛔ ${symbol} bloqué — vide de volume (POC=${volProfile.poc?.toFixed(2)})`);
                continue;
            }

            // ── 7. MTF gate — rejette les contre-tendances ────────
            if (mtf?.counterTrend) {
                logger.info(`⛔ ${symbol} bloqué — contre-tendance H1`);
                continue;
            }

            // ── 8. Confluence minimum ────────────────────────────
            if (mtf?.confluence === 'LOW') {
                logger.info(`⛔ ${symbol} bloqué — confluence MTF faible`);
                continue;
            }

            // ── 9. SL/TP valides ? ────────────────────────────────
            if (!levels || levels.rr < 1.5) continue;
            const { sl, tp, rr, atr } = levels;

            // Direction SL/TP correcte
            if (direction === 'BUY'  && (sl >= livePrice || tp <= livePrice)) continue;
            if (direction === 'SELL' && (sl <= livePrice || tp >= livePrice)) continue;

            // ── 10. Cooldown ──────────────────────────────────────
            const ck = `${symbol}:${direction}`;
            if (cooldown[ck] && now - cooldown[ck] < COOLDOWN_MS) continue;

            // ── 11. Build signal ──────────────────────────────────
            const dec = DECIMALS[symbol] ?? DECIMALS.default;

            const sig = {
                id:              `${symbol.replace('/', '')}-${now}`,
                symbol,
                signal:          direction,
                confidence,
                compositeScore:  score,
                entry:           +livePrice.toFixed(dec),
                stopLoss:        +sl.toFixed(dec),
                takeProfit:      +tp.toFixed(dec),
                rr:              +rr.toFixed(2),
                reasoning:       signals.slice(0, 5).join(' | '),
                // MTF detail
                mtfConfluence:   mtf.confluence,
                mtfDirection:    mtf.direction,
                tf1Bias:         mtf.tf1.bias,
                tf15Bias:        mtf.tf15.bias,
                tf60Bias:        mtf.tf60.bias,
                // SMC
                smcBias:         smc.bias,
                inducement:      smc.inducement?.desc || null,
                liquiditySweep:  smc.liquiditySweep?.desc || null,
                // ICT
                killZone:        ict.killZone?.name || null,
                ote:             ict.ote?.type || null,
                // Volume
                poc:             volProfile?.poc ? +volProfile.poc.toFixed(dec) : null,
                vwap:            volProfile?.vwap ? +volProfile.vwap.toFixed(dec) : null,
                nearPOC:         volProfile?.nearPOC,
                // DXY
                dxyBias:         dxy?.dxyBias || null,
                // Kelly
                kellySafe:       kelly?.kellySafe || null,
                kellyNote:       kelly?.riskNote || null,
                // ADX (force de tendance)
                adx:             mtf.tf1.adx     || null,
                adxH1:           mtf.tf60.adx    || null,
                // Fibonacci auto
                fibonacci:       mtf.tf1.fibonacci || null,
                // Régime marché
                regime:          mtf.tf1.regime   || null,
                // Ichimoku M1
                ichimoku:        mtf.tf1.ichimoku  || null,
                // SuperTrend M1
                supertrend:      mtf.tf1.supertrend || null,
                // Divergences M1
                divergence:      mtf.tf1.divergence || null,
                // Rejection candles M1
                rejection:       mtf.tf1.rejection  || null,
                // MSS (Market Structure Shift)
                mss:             analysis.smc?.mss   || null,
                // Premium/Discount zone ICT
                premiumDiscount: analysis.ict?.premiumDiscount || null,
                // Prochaine Kill Zone
                nextKillZone:    analysis.ict?.nextKillZone   || null,
                // Structure H1 (HH/HL)
                h1Ichimoku:      mtf.tf60.ichimoku  || null,
                h1Supertrend:    mtf.tf60.supertrend || null,
                // Données complètes pour StrategyPanel
                strategy: {
                    score, direction, signals: signals || [],
                    smc: analysis.smc,
                    ict: analysis.ict,
                    hlz: analysis.hlz,
                    orderFlow: {
                        buyPressure:  mtf.tf1.bull ? Math.round(mtf.tf1.bull / (mtf.tf1.bull + mtf.tf1.bear + 0.01) * 100) : 50,
                        sellPressure: mtf.tf1.bear ? Math.round(mtf.tf1.bear / (mtf.tf1.bull + mtf.tf1.bear + 0.01) * 100) : 50,
                        delta:   (mtf.tf1.bull || 0) - (mtf.tf1.bear || 0),
                        imbalance: mtf.tf1.bull > mtf.tf1.bear + 3 ? 'bullish' : mtf.tf1.bear > mtf.tf1.bull + 3 ? 'bearish' : 'neutral',
                        momentum: mtf.tf1.bias,
                    },
                    mtf: { direction: mtf.direction, strength: mtf.strength, confluence: mtf.confluence, tf1: mtf.tf1, tf15: mtf.tf15, tf60: mtf.tf60 },
                    adx: mtf.tf1.adx, fibonacci: mtf.tf1.fibonacci, regime: mtf.tf1.regime,
                    ichimoku: mtf.tf1.ichimoku, supertrend: mtf.tf1.supertrend,
                    divergence: mtf.tf1.divergence, rejection: mtf.tf1.rejection,
                    volProfile, dxy,
                },
                // Meta
                atr:             +atr.toFixed(dec),
                candleSource:    m1Hist.source,
                priceSource:     priceData.source,
                levelsFixed:     true,
                timestamp:       now,
                aiEngine:        'auto-v8',
                source:          'scheduler',
            };

            cooldown[ck]        = now;
            lastSignals[symbol] = sig;

            const sent = broadcastSignal(sig);

            // Telegram notification
            telegram.sendSignal(sig).catch(() => {});

            logger.info(`✅ v8 ${symbol} ${direction} | conf=${confidence}% | score=${score} | RR=${rr} | MTF=${mtf.confluence} | SL=${sl.toFixed(dec)} TP=${tp.toFixed(dec)} | kelly=${kelly?.kellySafe}% → ${sent} clients`);

        } catch (err) {
            logger.warn(`AutoSignal v8 erreur ${symbol}`, { err: err.message });
        }
    }
}

function registerClient(ws)   { clients.add(ws); }
function unregisterClient(ws) { clients.delete(ws); }

function start(intervalMinutes = 1) {
    if (isRunning) stop();
    setTimeout(generateAndBroadcast, 2000); // premier scan après 2s
    scheduler = setInterval(generateAndBroadcast, Math.max(1, intervalMinutes) * 60 * 1000);
    isRunning = true;
    logger.info(`AutoSignal v8 démarré — MTF+SMC+ICT+DXY+VolProfile+Kelly | scan ${intervalMinutes}min`);
    telegram.sendBotStatus(true, intervalMinutes).catch(() => {});
}

function stop() {
    if (scheduler) { clearInterval(scheduler); scheduler = null; }
    isRunning = false;
    telegram.sendBotStatus(false, 0).catch(() => {});
}

function getStatus() {
    return {
        running:         isRunning,
        version:         'v8',
        intervalMinutes: 1,
        clients:         clients.size,
        modules:         ['MTF-M1/M15/H1', 'SMC', 'ICT', 'HLZ', 'VolumeProfile', 'DXY', 'Kelly', 'ADX', 'Fibonacci', 'Regime', 'Ichimoku', 'SuperTrend', 'Divergences'],
        lastSignals:     Object.entries(lastSignals).map(([s, sig]) => ({
            symbol: s, signal: sig.signal, entry: sig.entry,
            sl: sig.stopLoss, tp: sig.takeProfit, rr: sig.rr,
            mtf: sig.mtfConfluence, kelly: sig.kellySafe,
            ageMin: Math.round((Date.now() - sig.timestamp) / 60000),
        })),
    };
}

module.exports = { registerClient, unregisterClient, start, stop, getStatus };