'use strict';

const logger = require('../utils/logger');
const { getPrice } = require('../services/priceAggregator');

const clients = new Set();
let broadcastTimer = null;

function generateAutoSignal(symbol, price) {
    const score = Math.round((Math.random() - 0.5) * 200);
    const clamped = Math.max(-100, Math.min(100, score));
    let signal = 'HOLD';
    if (clamped >= 50) signal = 'BUY';
    else if (clamped <= -50) signal = 'SELL';
    const atr = price * 0.002;
    return {
        symbol,
        signal,
        compositeScore: clamped,
        confidence: Math.abs(clamped),
        entry: price,
        stopLoss: signal === 'BUY' ? price - atr * 1.5 : price + atr * 1.5,
        takeProfit: signal === 'BUY' ? price + atr * 3 : price - atr * 3,
        reasoning: `Auto signal — score ${clamped}`,
        timestamp: Date.now(),
    };
}

async function broadcast() {
    if (clients.size === 0) return;
    try {
        const symbols = ['XAU/USD', 'BTC/USD', 'EUR/USD'];
        for (const symbol of symbols) {
            const { price } = await getPrice(symbol);
            const signal = generateAutoSignal(symbol, price);
            const payload = JSON.stringify({ type: 'signal', ...signal });
            for (const ws of clients) {
                if (ws.readyState === ws.OPEN) {
                    try { ws.send(payload); } catch { /* ignore */ }
                }
            }
        }
    } catch (err) {
        logger.warn('Signal stream error', { err: err.message });
    }
}

function start() {
    if (broadcastTimer) return;
    broadcastTimer = setInterval(broadcast, 30000); // every 30s
    logger.info('Signal stream started');
}

function registerClient(ws) {
    clients.add(ws);
    start();
}

function unregisterClient(ws) {
    clients.delete(ws);
}

module.exports = { registerClient, unregisterClient };
